# ImmunoAI Design Guidelines

## Design Approach: Medical-Grade Digital Health Interface

**Selected Framework**: Apple Human Interface Guidelines + Healthcare Industry Standards
**Rationale**: Medical applications demand exceptional clarity, trust, and accessibility. The design balances clinical precision with approachable warmth, ensuring users feel confident while engaging with complex health data.

**Core Principles**:
- Clinical Clarity: Every element serves a clear purpose in communicating health data
- Trustworthy Precision: Design choices reinforce accuracy and reliability
- Empowering Transparency: Complex data presented in understandable, actionable formats
- Calming Professionalism: Medical-grade interface that doesn't intimidate

---

## Typography System

**Primary Font**: SF Pro Display (Apple system font) or Inter for universal compatibility
**Secondary Font**: SF Mono for numerical health data and scores

**Hierarchy**:
- Display (Hero Numbers): 72px/bold - ImmunoScore™ primary display
- H1 (Section Headers): 32px/semibold - Dashboard sections, page titles
- H2 (Subsections): 24px/semibold - Metric categories, card headers
- H3 (Labels): 18px/medium - Data point labels, feature names
- Body Large: 16px/regular - Primary content, explanations
- Body: 14px/regular - Supporting text, descriptions
- Small/Caption: 12px/regular - Timestamps, metadata, fine print
- Data Display: 28px/medium (SF Mono) - Numerical health metrics

---

## Layout System

**Spacing Units**: Tailwind spacing - 2, 4, 6, 8, 12, 16, 24, 32
**Primary Rhythm**: Base-8 system for vertical spacing (8, 16, 24, 32)
**Container Widths**: 
- Full dashboard: max-w-7xl
- Content cards: max-w-4xl
- Data visualization panels: max-w-6xl

**Grid System**:
- Dashboard: 12-column grid with 16px gutters
- Metric cards: 3-column desktop (grid-cols-3), 1-column mobile
- Scan interface: Full-width centered layout with max-w-2xl

---

## Component Library

### Navigation & Structure
**App Header**:
- Fixed position with subtle backdrop blur
- Logo left, ImmunoScore badge center, profile/settings right
- Height: 64px with 1px bottom border
- Translucent background for depth

**Sidebar Navigation** (Desktop Only):
- Fixed left panel, 240px width
- Icons + labels for: Dashboard, New Scan, History, Education, Settings
- Active state: subtle background with accent border-left-4
- Collapse to icon-only on tablet

**Bottom Navigation** (Mobile):
- Fixed bottom with 5 primary actions
- Icon + label format, 56px height
- Safe area padding for notched devices

### Core UI Elements

**Primary Scan Interface**:
- Full-screen camera viewport with overlay guides
- Circular camera frame (400px diameter desktop, 300px mobile)
- Pulsing ring animation during active scan
- Real-time feedback indicators overlaid on corners
- Progress arc showing scan completion (0-100%)

**ImmunoScore Display Card**:
- Large central circle (240px diameter) with gradient fill
- Score displayed as 0-100 in 72px bold
- Outer progress ring showing percentile
- Status indicator: Green (80-100), Amber (50-79), Red (<50)
- Subtitle showing interpretation: "Strong," "Moderate," "Needs Attention"

**Metric Visualization Cards**:
- Compact cards in 3-column grid
- Icon + label header (16px icon, 14px label)
- Primary metric in 28px medium (SF Mono)
- Sparkline trend graph below (80px height)
- Comparison indicator: ↑/↓ with percentage change
- Border-left accent matching status

**3D Immune Map Visualization**:
- Full-width panel with aspect-ratio-16/9 container
- Dark background for contrast with 3D elements
- Interactive controls: Rotate, zoom, layer toggles
- Color-coded regions showing immune response patterns
- Hover tooltips with detailed metric breakdowns

**Timeline History View**:
- Vertical timeline with connected dots
- Each entry: Date, ImmunoScore badge, key metrics
- Expandable cards revealing full scan details
- Trend line connecting scores across timeline
- Filter controls: Last 7 days, 30 days, 90 days, All

### Data Display Components

**Health Metric Cards**:
- White background with subtle shadow (shadow-sm)
- Padding: p-6
- Rounded corners: rounded-xl
- Border: 1px in neutral-200
- Organized sections with dividers

**Alert/Warning Banners**:
- Prominent top placement when risk detected
- Icon + message + action button layout
- Color-coded: Red (urgent), Amber (warning), Blue (info)
- Dismissible with × button
- Rounded-lg with p-4 padding

**Progress Indicators**:
- Circular progress for scan completion
- Linear progress bars for metric ranges
- Animated transitions using smooth easing
- Percentage labels positioned end-aligned

### Interactive Elements

**Primary Action Button** (Start Scan):
- Large format: 56px height × 240px width
- Rounded-full design
- Icon + text label
- Pulsing glow effect when ready
- Disabled state with opacity-50

**Secondary Buttons** (Export, Share):
- Medium format: 44px height
- Rounded-lg design
- Icon + text or text-only
- Outline or subtle background variants

**Toggle Switches** (Settings):
- iOS-style switches, 52px × 32px
- Smooth slide animation
- Clear on/off states

**Tabs** (Dashboard Sections):
- Horizontal pill-style tabs
- Active: filled background
- Inactive: transparent with hover state
- Indicator bar slides smoothly between tabs

### Educational Overlays

**Info Tooltips**:
- ⓘ icon triggers on hover/tap
- Popover with max-w-xs
- Arrow pointing to trigger element
- Padding: p-4, rounded-lg

**Onboarding Flow**:
- Full-screen step-by-step guide on first use
- Large illustrations (300px height)
- Progress dots at bottom
- Skip/Next navigation
- Gradient background for visual appeal

**Metric Explainers**:
- Expandable accordion sections
- "Learn More" links opening modal dialogs
- Illustrations + text explanations
- Close button and background overlay

---

## Images

**Hero Section** (Landing/Home):
- Large hero image showing smartphone scanning face
- Image should depict: Person holding phone at face level with confident, calm expression
- Modern clinical environment or gradient background
- Image treatment: Subtle overlay with gradient (top to bottom, opacity 40%)
- Hero text overlaid with backdrop-filter blur for readability
- Image dimensions: Full viewport width, 600px height desktop, 400px mobile

**Dashboard Illustrations**:
- Abstract immune system visualization graphics in header
- Soft, flowing organic shapes suggesting cellular activity
- Placement: Top of dashboard as decorative accent (200px height)

**Educational Content**:
- Diagram illustrations showing how PPG works
- Simple line-art style graphics for immune system basics
- Icon-based infographics for scan process steps

**No images needed for**: Scan interface (camera feed), metric displays, data visualizations

---

## Animations

**Use Sparingly - Medical Context**:
- Scan progress: Smooth circular progress animation (2s duration)
- Score reveal: Count-up animation from 0 to final score (1.5s)
- Card entrance: Subtle fade-in + slide-up (0.3s, stagger by 0.1s)
- Tab transitions: Smooth slide between views (0.2s)
- Tooltips: Gentle fade + scale entrance (0.15s)

**Prohibited**: Distracting hover effects, excessive micro-interactions, bouncing elements

---

## Accessibility & Polish

- Minimum touch targets: 44×44px (iOS standard)
- Color contrast: WCAG AA compliant throughout (4.5:1 minimum)
- Focus states: 2px outline in accent color with offset
- Screen reader labels for all interactive elements
- Keyboard navigation: Tab order follows visual hierarchy
- Loading states: Skeleton screens for data fetching
- Error states: Inline validation with helpful messaging
- Empty states: Friendly illustrations with guidance

---

## Platform-Specific Considerations

**Mobile Optimization**:
- Camera interface optimized for portrait orientation
- One-handed operation for primary actions
- Bottom sheet modals for secondary content
- Swipe gestures for navigation between scans
- Safe area padding for notched displays

**Desktop Enhancement**:
- Multi-column layouts utilizing screen space
- Keyboard shortcuts displayed in tooltips
- Hover states providing additional context
- Side-by-side comparison views for history

This medical-grade design system ensures ImmunoAI communicates complex health data with clarity and inspires user confidence through every interaction.