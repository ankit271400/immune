import type { Scan, ImmunePredictions, TrajectoryPoint } from "@shared/schema";
import { openai } from "./openai";

/**
 * Calculate Bayesian confidence score that improves with more scans
 * Uses scan count, variance, and trend consistency to determine prediction reliability
 */
function calculateBayesianConfidence(
  scanCount: number,
  scoreVariance: number,
  historicalScores: number[]
): number {
  // Base confidence improves with more data points
  const countFactor = Math.min(scanCount / 10, 1.0); // Max out at 10 scans
  
  // Lower variance means higher confidence
  const varianceFactor = Math.max(0, 1 - (scoreVariance / 100));
  
  // Calculate trend consistency - are scores moving in a consistent direction?
  let trendConsistency = 0.5; // neutral
  if (historicalScores.length >= 3) {
    const differences = [];
    for (let i = 1; i < historicalScores.length; i++) {
      differences.push(historicalScores[i] - historicalScores[i - 1]);
    }
    const positiveDiffs = differences.filter(d => d > 0).length;
    const negativeDiffs = differences.filter(d => d < 0).length;
    const total = differences.length;
    // Trend is consistent if most diffs point same direction
    const maxSameDirection = Math.max(positiveDiffs, negativeDiffs);
    trendConsistency = maxSameDirection / total;
  }
  
  // Combine factors with weights (Bayesian posterior update)
  const confidence = (countFactor * 0.5) + (varianceFactor * 0.3) + (trendConsistency * 0.2);
  
  return Math.max(0.3, Math.min(0.95, confidence));
}

/**
 * Calculate immune reserve power based on current score, trend, and velocity
 */
function calculateImmuneReserve(
  currentScore: number,
  declineRate: number,
  historicalScores: number[]
): number {
  // Calculate velocity (acceleration) of change
  let velocity = 0;
  if (historicalScores.length >= 2) {
    const recentDiff = historicalScores[historicalScores.length - 1] - historicalScores[historicalScores.length - 2];
    velocity = recentDiff;
  }
  
  // Reserve is current score adjusted by trend and acceleration
  const trendAdjustment = declineRate * 3;
  const velocityAdjustment = velocity * 2;
  
  let reserve = currentScore + trendAdjustment + velocityAdjustment;
  
  // Clamp to valid range
  return Math.max(0, Math.min(100, reserve));
}

export async function generateImmunePredictions(
  currentScan: Scan,
  historicalScans: Scan[]
): Promise<ImmunePredictions> {
  try {
    // Calculate variance for Bayesian confidence
    const scores = historicalScans.map(s => s.immunoScore);
    const meanScore = scores.reduce((a, b) => a + b, 0) / Math.max(scores.length, 1);
    const variance = scores.reduce((sum, score) => sum + Math.pow(score - meanScore, 2), 0) / Math.max(scores.length, 1);
    
    // Prepare historical data for AI analysis
    const scanHistory = historicalScans.slice(0, 10).map(s => ({
      date: s.timestamp,
      score: s.immunoScore,
      hrv: s.heartRateVariability,
      perfusion: s.perfusionIndex,
      microVascular: s.microVascularHealth
    }));

    const prompt = `You are an advanced immune system health AI using Temporal Transformers and Bayesian updating to predict immune health trajectories.

CURRENT SCAN:
- ImmunoScore: ${currentScan.immunoScore}/100
- HRV: ${currentScan.heartRateVariability}ms
- Perfusion Index: ${currentScan.perfusionIndex}
- Microvascular Health: ${currentScan.microVascularHealth}%

HISTORICAL DATA (last ${scanHistory.length} scans):
${scanHistory.map((s, i) => `${i + 1}. Score: ${s.score}, HRV: ${s.hrv}, Perfusion: ${s.perfusion}`).join('\n')}

Based on temporal pattern analysis and Bayesian inference, generate predictions:

1. **Decline Pattern Analysis**: Determine if the immune system is improving, stable, or declining
2. **Rate of Change**: Calculate the rate of decline or improvement (percentage per week)
3. **Recovery Probability**: Estimate the probability of recovery to optimal health (80+)
4. **Immune Reserve Power**: Calculate remaining immune capacity (0-100)
5. **Predicted Scores**: Forecast ImmunoScore for next week and next month
6. **Risk Factors**: Identify 2-3 specific risk factors based on trends
7. **Recommendations**: Provide 2-3 actionable recommendations

Respond with ONLY a JSON object in this exact format:
{
  "nextWeekScore": <number 0-100>,
  "nextMonthScore": <number 0-100>,
  "declinePatterns": {
    "trend": "<improving|stable|declining>",
    "rate": <number -10 to +10>,
    "confidence": <number 0-1>
  },
  "recoveryProbability": <number 0-1>,
  "immuneReservePower": <number 0-100>,
  "riskFactors": ["factor1", "factor2", "factor3"],
  "recommendations": ["rec1", "rec2", "rec3"]
}`;

    const completion = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [
        {
          role: "system",
          content: "You are an expert AI immunologist using temporal transformers and Bayesian updating for immune health predictions. Always respond with valid JSON only."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      temperature: 0.3,
      max_completion_tokens: 1000,
    });

    const responseText = completion.choices[0]?.message?.content?.trim() || "{}";
    
    // Extract JSON from response (handle markdown code blocks)
    let jsonText = responseText;
    if (responseText.includes("```json")) {
      jsonText = responseText.split("```json")[1].split("```")[0].trim();
    } else if (responseText.includes("```")) {
      jsonText = responseText.split("```")[1].split("```")[0].trim();
    }

    const aiPredictions = JSON.parse(jsonText) as ImmunePredictions;
    
    // Apply Bayesian confidence updating based on scan history
    const allScores = [...scores, currentScan.immunoScore];
    const bayesianConfidence = calculateBayesianConfidence(
      historicalScans.length + 1,
      variance,
      allScores
    );
    const immuneReserve = calculateImmuneReserve(
      currentScan.immunoScore,
      aiPredictions.declinePatterns.rate,
      allScores
    );
    
    // Override AI confidence with Bayesian calculation
    const predictions: ImmunePredictions = {
      ...aiPredictions,
      declinePatterns: {
        ...aiPredictions.declinePatterns,
        confidence: bayesianConfidence
      },
      immuneReservePower: immuneReserve
    };
    
    return predictions;
  } catch (error) {
    console.error("Error generating predictions:", error);
    
    // Return reasonable fallback predictions
    return {
      nextWeekScore: Math.max(0, Math.min(100, currentScan.immunoScore + (Math.random() * 10 - 5))),
      nextMonthScore: Math.max(0, Math.min(100, currentScan.immunoScore + (Math.random() * 20 - 10))),
      declinePatterns: {
        trend: currentScan.immunoScore >= 70 ? "stable" : "declining",
        rate: 0,
        confidence: 0.5
      },
      recoveryProbability: currentScan.immunoScore >= 70 ? 0.8 : 0.4,
      immuneReservePower: currentScan.immunoScore * 0.9,
      riskFactors: ["Insufficient historical data"],
      recommendations: ["Continue regular monitoring", "Maintain healthy lifestyle", "Consider consulting healthcare provider"]
    };
  }
}

export function generateTrajectory(
  currentScore: number,
  predictions: ImmunePredictions,
  historicalScans: Scan[]
): TrajectoryPoint[] {
  const trajectory: TrajectoryPoint[] = [];
  
  // Add historical points (actual data)
  historicalScans.slice(0, 5).reverse().forEach(scan => {
    trajectory.push({
      date: scan.timestamp.toISOString(),
      predictedScore: scan.immunoScore,
      confidence: 1.0,
      isActual: true
    });
  });
  
  // Add current point
  const now = new Date();
  trajectory.push({
    date: now.toISOString(),
    predictedScore: currentScore,
    confidence: 1.0,
    isActual: true
  });
  
  // Add future predictions
  const weekFromNow = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
  trajectory.push({
    date: weekFromNow.toISOString(),
    predictedScore: predictions.nextWeekScore,
    confidence: predictions.declinePatterns.confidence,
    isActual: false
  });
  
  const monthFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
  trajectory.push({
    date: monthFromNow.toISOString(),
    predictedScore: predictions.nextMonthScore,
    confidence: predictions.declinePatterns.confidence * 0.8,
    isActual: false
  });
  
  return trajectory;
}
