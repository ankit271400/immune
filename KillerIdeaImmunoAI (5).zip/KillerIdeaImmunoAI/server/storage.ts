import { scans, immunoGraphs, mirrorScans, type Scan, type InsertScan, type ImmunoGraph, type InsertImmunoGraph, type MirrorScan, type InsertMirrorScan } from "@shared/schema";
import { db } from "./db";
import { eq, desc, lt } from "drizzle-orm";

export interface IStorage {
  getScan(id: string): Promise<Scan | undefined>;
  getAllScans(): Promise<Scan[]>;
  createScan(scan: InsertScan): Promise<Scan>;
  getImmunoGraph(userId: string): Promise<ImmunoGraph | undefined>;
  createOrUpdateImmunoGraph(graph: InsertImmunoGraph): Promise<ImmunoGraph>;
  getMirrorScans(): Promise<MirrorScan[]>;
  createMirrorScan(scan: InsertMirrorScan): Promise<MirrorScan>;
  cleanupOldScans(): Promise<void>;
  cleanupOldMirrorScans(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getScan(id: string): Promise<Scan | undefined> {
    const [scan] = await db.select().from(scans).where(eq(scans.id, id));
    return scan || undefined;
  }

  async getAllScans(): Promise<Scan[]> {
    // Cleanup old scans first
    await this.cleanupOldScans();
    return await db.select().from(scans).orderBy(desc(scans.timestamp));
  }

  async createScan(insertScan: InsertScan): Promise<Scan> {
    const [scan] = await db
      .insert(scans)
      .values(insertScan as any)
      .returning();
    return scan;
  }

  async getImmunoGraph(userId: string = "default_user"): Promise<ImmunoGraph | undefined> {
    const [graph] = await db
      .select()
      .from(immunoGraphs)
      .where(eq(immunoGraphs.userId, userId))
      .orderBy(desc(immunoGraphs.updatedAt))
      .limit(1);
    return graph || undefined;
  }

  async createOrUpdateImmunoGraph(insertGraph: InsertImmunoGraph): Promise<ImmunoGraph> {
    const existing = await this.getImmunoGraph(insertGraph.userId || "default_user");
    
    if (existing) {
      const updateData: any = {
        ...insertGraph,
        updatedAt: new Date(),
      };
      
      const [updated] = await db
        .update(immunoGraphs)
        .set(updateData)
        .where(eq(immunoGraphs.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(immunoGraphs)
        .values(insertGraph as any)
        .returning();
      return created;
    }
  }

  async getMirrorScans(): Promise<MirrorScan[]> {
    // First cleanup old scans
    await this.cleanupOldMirrorScans();
    return await db.select().from(mirrorScans).orderBy(desc(mirrorScans.timestamp));
  }

  async createMirrorScan(insertScan: InsertMirrorScan): Promise<MirrorScan> {
    const [scan] = await db
      .insert(mirrorScans)
      .values(insertScan)
      .returning();
    return scan;
  }

  async cleanupOldScans(): Promise<void> {
    // Calculate date 6 months ago
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    // Delete all scans (all sources) older than 6 months
    await db.delete(scans).where(lt(scans.timestamp, sixMonthsAgo));
    console.log(`[Storage] Cleaned up all scans older than 6 months`);
  }

  async cleanupOldMirrorScans(): Promise<void> {
    // Calculate date 6 months ago
    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

    // Delete scans older than 6 months
    await db.delete(mirrorScans).where(lt(mirrorScans.timestamp, sixMonthsAgo));
    console.log(`[Storage] Cleaned up mirror scans older than 6 months`);
  }
}

export const storage = new DatabaseStorage();
