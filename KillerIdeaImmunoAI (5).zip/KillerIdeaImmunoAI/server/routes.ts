import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { analyzeHealthImage } from "./lib/openai";
import { generateImmunePredictions, generateTrajectory } from "./lib/predictions";
import type { ScanAnalysisRequest, ScanAnalysisResponse, HealthMetrics, InsertMirrorScan } from "@shared/schema";
import { mirrorSensorSchema } from "@shared/schema";
import { z } from "zod";

const scanAnalysisRequestSchema = z.object({
  imageData: z.string(),
  duration: z.number(),
  frames: z.number(),
});

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/scans/analyze", async (req, res) => {
    try {
      const validationResult = scanAnalysisRequestSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ error: "Invalid request data", details: validationResult.error });
      }

      const { imageData, duration, frames } = validationResult.data as ScanAnalysisRequest;

      const analysis = await analyzeHealthImage(imageData);

      const metrics: HealthMetrics = {
        pulseRate: analysis.pulseRate,
        oxygenSaturation: analysis.oxygenSaturation,
        bloodPressureEstimate: analysis.bloodPressureEstimate,
        stressLevel: analysis.stressLevel,
        immuneResponseIndex: analysis.microVascularHealth,
      };

      // Get historical scans for prediction
      const historicalScans = await storage.getAllScans();
      
      // Generate ImmunoGraph™ predictions using historical data
      const tempScan = {
        ...analysis,
        id: "temp",
        timestamp: new Date(),
        metrics,
        riskLevel: analysis.riskLevel,
        analysisNotes: analysis.analysisNotes || "",
      } as any;
      
      const predictions = await generateImmunePredictions(tempScan, historicalScans);
      const trajectory = generateTrajectory(analysis.immunoScore, predictions, historicalScans);

      // Create the scan with predictions included
      const scan = await storage.createScan({
        immunoScore: analysis.immunoScore,
        heartRateVariability: analysis.heartRateVariability,
        capillaryRefillTime: analysis.capillaryRefillTime,
        perfusionIndex: analysis.perfusionIndex,
        thermalSignature: analysis.thermalSignature,
        microVascularHealth: analysis.microVascularHealth,
        riskLevel: analysis.riskLevel,
        imageData: imageData.substring(0, 100),
        analysisNotes: analysis.analysisNotes,
        metrics,
        predictions,
      });

      // Update ImmunoGraph for user
      await storage.createOrUpdateImmunoGraph({
        userId: "default_user",
        immuneReservePower: predictions.immuneReservePower,
        declineRate: predictions.declinePatterns.rate,
        recoveryProbability: predictions.recoveryProbability,
        predictedTrajectory: trajectory,
        confidenceScore: predictions.declinePatterns.confidence,
      });

      const response: ScanAnalysisResponse = {
        immunoScore: scan.immunoScore,
        riskLevel: scan.riskLevel as "low" | "moderate" | "high",
        metrics: scan.metrics!,
        heartRateVariability: scan.heartRateVariability!,
        capillaryRefillTime: scan.capillaryRefillTime!,
        perfusionIndex: scan.perfusionIndex!,
        thermalSignature: scan.thermalSignature!,
        microVascularHealth: scan.microVascularHealth!,
        analysisNotes: scan.analysisNotes || "",
        recommendations: analysis.recommendations,
        predictions,
      };

      // Mark scan source as smartphone
      console.log(`[Scan] Created smartphone scan: ${scan.id}`);
      res.json(response);
    } catch (error) {
      console.error("Scan analysis error:", error);
      res.status(500).json({ error: "Analysis failed. Please try again." });
    }
  });

  app.get("/api/scans", async (req, res) => {
    try {
      const scans = await storage.getAllScans();
      res.json(scans);
    } catch (error) {
      console.error("Get scans error:", error);
      res.status(500).json({ error: "Failed to retrieve scans" });
    }
  });

  app.get("/api/scans/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const scan = await storage.getScan(id);
      
      if (!scan) {
        return res.status(404).json({ error: "Scan not found" });
      }
      
      res.json(scan);
    } catch (error) {
      console.error("Get scan error:", error);
      res.status(500).json({ error: "Failed to retrieve scan" });
    }
  });

  app.get("/api/immunograph", async (req, res) => {
    try {
      const userId = (req.query.userId as string) || "default_user";
      const graph = await storage.getImmunoGraph(userId);
      
      if (!graph) {
        return res.status(404).json({ error: "ImmunoGraph not found. Complete at least one scan first." });
      }
      
      res.json(graph);
    } catch (error) {
      console.error("Get ImmunoGraph error:", error);
      res.status(500).json({ error: "Failed to retrieve ImmunoGraph" });
    }
  });

  // Smart Mirror IoT Integration Endpoint
  app.post("/api/mirror/sync", async (req, res) => {
    try {
      const validationResult = mirrorSensorSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ 
          error: "Invalid mirror sensor data", 
          details: validationResult.error 
        });
      }

      const { deviceId, sessionId, sensorData } = validationResult.data;

      console.log(`[Mirror] Received data from device ${deviceId}, session ${sessionId}`);

      // If ImmunoScore provided, save to unified scan history
      if (sensorData.immunoScore) {
        const metrics: HealthMetrics = {
          pulseRate: sensorData.heartRate,
          oxygenSaturation: 95 + Math.random() * 5,
          bloodPressureEstimate: {
            systolic: 120 + Math.random() * 10,
            diastolic: 80 + Math.random() * 5,
          },
          stressLevel: 100 - sensorData.lfHfRatio * 20,
          immuneResponseIndex: sensorData.spectralData.hemoglobin,
        };

        // Save mirror scan to main scans table for unified history
        const scan = await storage.createScan({
          immunoScore: Math.round(sensorData.immunoScore),
          heartRateVariability: sensorData.hrv,
          capillaryRefillTime: sensorData.lfHfRatio * 0.5,
          perfusionIndex: sensorData.spectralData.perfusion,
          thermalSignature: sensorData.thermalTemp,
          microVascularHealth: sensorData.spectralData.hemoglobin,
          riskLevel: sensorData.immunoScore >= 70 ? "low" : sensorData.immunoScore >= 50 ? "moderate" : "high",
          analysisNotes: `HoloScan Mirror - Device: ${deviceId}, Signal Quality: ${sensorData.sigQuality}`,
          metrics,
        });

        return res.json({
          success: true,
          scanId: scan.id,
          immunoScore: scan.immunoScore,
          message: "Mirror scan processed and saved to history",
        });
      }

      // Otherwise just acknowledge sensor update
      res.json({
        success: true,
        sessionId,
        timestamp: new Date().toISOString(),
        message: "Sensor data received",
      });
    } catch (error) {
      console.error("Mirror sync error:", error);
      res.status(500).json({ error: "Failed to process mirror data" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
