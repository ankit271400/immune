import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, jsonb, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const scans = pgTable("scans", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  immunoScore: integer("immuno_score").notNull(),
  heartRateVariability: real("heart_rate_variability"),
  capillaryRefillTime: real("capillary_refill_time"),
  perfusionIndex: real("perfusion_index"),
  thermalSignature: real("thermal_signature"),
  microVascularHealth: real("micro_vascular_health"),
  riskLevel: text("risk_level").notNull(),
  imageData: text("image_data"),
  analysisNotes: text("analysis_notes"),
  metrics: jsonb("metrics").$type<HealthMetrics>(),
  predictions: jsonb("predictions").$type<ImmunePredictions>(),
});

export const immunoGraphs = pgTable("immuno_graphs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: text("user_id").notNull().default("default_user"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  immuneReservePower: real("immune_reserve_power"),
  declineRate: real("decline_rate"),
  recoveryProbability: real("recovery_probability"),
  predictedTrajectory: jsonb("predicted_trajectory").$type<TrajectoryPoint[]>(),
  confidenceScore: real("confidence_score"),
});

export const mirrorScans = pgTable("mirror_scans", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  deviceId: text("device_id").notNull(),
  sessionId: text("session_id").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  immunoScore: integer("immuno_score").notNull(),
  heartRate: real("heart_rate"),
  hrv: real("hrv"),
  lfHfRatio: real("lf_hf_ratio"),
  thermalTemp: real("thermal_temp"),
  spectralData: jsonb("spectral_data").$type<{hemoglobin: number; melanin: number; perfusion: number; infrared: number; nirIntensity: number}>(),
  sigQuality: text("sig_quality").notNull(),
  riskLevel: text("risk_level").notNull(),
  metrics: jsonb("metrics").$type<HealthMetrics>(),
});

export const insertScanSchema = createInsertSchema(scans).omit({
  id: true,
  timestamp: true,
});

export const insertMirrorScanSchema = createInsertSchema(mirrorScans).omit({
  id: true,
  timestamp: true,
});

export type InsertScan = z.infer<typeof insertScanSchema>;
export type Scan = typeof scans.$inferSelect;
export type InsertMirrorScan = z.infer<typeof insertMirrorScanSchema>;
export type MirrorScan = typeof mirrorScans.$inferSelect;

export interface HealthMetrics {
  pulseRate: number;
  oxygenSaturation: number;
  bloodPressureEstimate: {
    systolic: number;
    diastolic: number;
  };
  stressLevel: number;
  immuneResponseIndex: number;
}

export interface ScanAnalysisRequest {
  imageData: string;
  duration: number;
  frames: number;
}

export interface ScanAnalysisResponse {
  immunoScore: number;
  riskLevel: "low" | "moderate" | "high";
  metrics: HealthMetrics;
  heartRateVariability: number;
  capillaryRefillTime: number;
  perfusionIndex: number;
  thermalSignature: number;
  microVascularHealth: number;
  analysisNotes: string;
  recommendations: string[];
  predictions?: ImmunePredictions;
}

export interface ImmunePredictions {
  nextWeekScore: number;
  nextMonthScore: number;
  declinePatterns: {
    trend: "improving" | "stable" | "declining";
    rate: number;
    confidence: number;
  };
  recoveryProbability: number;
  immuneReservePower: number;
  riskFactors: string[];
  recommendations: string[];
}

export interface TrajectoryPoint {
  date: string;
  predictedScore: number;
  confidence: number;
  isActual: boolean;
}

export interface ImmunoGraphData {
  id: string;
  userId: string;
  immuneReservePower: number;
  declineRate: number;
  recoveryProbability: number;
  predictedTrajectory: TrajectoryPoint[];
  confidenceScore: number;
  createdAt: Date;
  updatedAt: Date;
}

export const insertImmunoGraphSchema = createInsertSchema(immunoGraphs).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertImmunoGraph = z.infer<typeof insertImmunoGraphSchema>;
export type ImmunoGraph = typeof immunoGraphs.$inferSelect;

// Mirror Sensor Data
export interface MirrorSensorData {
  timestamp: string;
  thermalTemp: number;
  thermalHotspots: Array<{ region: string; temp: number }>;
  spectralData: {
    hemoglobin: number;
    melanin: number;
    perfusion: number;
    infrared: number;
    nirIntensity: number;
  };
  ppgWaveform: number[];
  heartRate: number;
  hrv: number;
  lfHfRatio: number;
  sigQuality: "poor" | "good" | "excellent";
  immunoScore?: number;
}

export interface MirrorSyncRequest {
  deviceId: string;
  sessionId: string;
  sensorData: MirrorSensorData;
}

export const mirrorSensorSchema = z.object({
  deviceId: z.string(),
  sessionId: z.string(),
  sensorData: z.object({
    timestamp: z.string(),
    thermalTemp: z.number(),
    thermalHotspots: z.array(z.object({ region: z.string(), temp: z.number() })),
    spectralData: z.object({
      hemoglobin: z.number(),
      melanin: z.number(),
      perfusion: z.number(),
      infrared: z.number(),
      nirIntensity: z.number(),
    }),
    ppgWaveform: z.array(z.number()),
    heartRate: z.number(),
    hrv: z.number(),
    lfHfRatio: z.number(),
    sigQuality: z.enum(["poor", "good", "excellent"]),
    immunoScore: z.number().optional(),
  }),
});
