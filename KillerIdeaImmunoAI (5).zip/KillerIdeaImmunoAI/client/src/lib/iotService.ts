import type { MirrorSensorData } from "@shared/schema";

// IoT Service for Smart Mirror Integration
// Supports MQTT/WebSocket connectivity with edge hardware

export interface MirrorSession {
  sessionId: string;
  deviceId: string;
  startTime: Date;
  status: "scanning" | "processing" | "complete" | "error";
  liveData: MirrorSensorData | null;
}

class IoTService {
  private sessions: Map<string, MirrorSession> = new Map();
  private mockInterval: NodeJS.Timeout | null = null;

  // Initialize connection to smart mirror
  async connectToMirror(deviceId: string): Promise<string> {
    const sessionId = Math.random().toString(36).substring(7);
    const session: MirrorSession = {
      sessionId,
      deviceId,
      startTime: new Date(),
      status: "scanning",
      liveData: null,
    };
    this.sessions.set(sessionId, session);
    console.log(`[IoT] Connected to mirror: ${deviceId}, session: ${sessionId}`);
    return sessionId;
  }

  // Update sensor data in real-time
  updateSensorData(sessionId: string, sensorData: MirrorSensorData): void {
    const session = this.sessions.get(sessionId);
    if (session) {
      session.liveData = sensorData;
      console.log(`[IoT] Updated sensor data for session ${sessionId}`);
    }
  }

  // Get current session data
  getSessionData(sessionId: string): MirrorSession | null {
    return this.sessions.get(sessionId) || null;
  }

  // Start mock sensor stream for testing
  startMockSensorStream(sessionId: string): void {
    const session = this.sessions.get(sessionId);
    if (!session) return;

    let frame = 0;
    this.mockInterval = setInterval(() => {
      frame++;
      const mockData: MirrorSensorData = {
        timestamp: new Date().toISOString(),
        thermalTemp: 35.5 + Math.random() * 2,
        thermalHotspots: [
          { region: "Left Cheek", temp: 35.8 + Math.random() * 1 },
          { region: "Right Cheek", temp: 35.7 + Math.random() * 1 },
          { region: "Under Eye", temp: 36.2 + Math.random() * 0.8 },
        ],
        spectralData: {
          hemoglobin: 65 + Math.random() * 20,
          melanin: 45 + Math.random() * 20,
          perfusion: 58 + Math.random() * 15,
          infrared: 75 + Math.random() * 15,
          nirIntensity: 82 + Math.random() * 12,
        },
        ppgWaveform: Array.from({ length: 120 }, () => 
          Math.sin(frame * 0.05) * 20 + 100 + Math.random() * 5
        ),
        heartRate: 72 + Math.random() * 8,
        hrv: 35 + Math.random() * 15,
        lfHfRatio: 1.8 + Math.random() * 0.6,
        sigQuality: frame % 3 === 0 ? "excellent" : "good",
      };

      this.updateSensorData(sessionId, mockData);

      // Complete after 10 frames (10 seconds)
      if (frame >= 10) {
        this.stopMockSensorStream();
        session.status = "complete";
        mockData.immunoScore = 72 + Math.random() * 20;
        this.updateSensorData(sessionId, mockData);
      }
    }, 1000);
  }

  // Stop mock sensor stream
  stopMockSensorStream(): void {
    if (this.mockInterval) {
      clearInterval(this.mockInterval);
      this.mockInterval = null;
    }
  }

  // Send data to backend API
  async sendSensorDataToAPI(deviceId: string, sessionId: string, sensorData: MirrorSensorData): Promise<any> {
    try {
      const response = await fetch("/api/mirror/sync", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          deviceId,
          sessionId,
          sensorData,
        }),
      });
      return await response.json();
    } catch (error) {
      console.error("[IoT] Error sending data to API:", error);
      throw error;
    }
  }

  // Disconnect session
  disconnect(sessionId: string): void {
    this.stopMockSensorStream();
    this.sessions.delete(sessionId);
    console.log(`[IoT] Disconnected session: ${sessionId}`);
  }
}

export const iotService = new IoTService();
