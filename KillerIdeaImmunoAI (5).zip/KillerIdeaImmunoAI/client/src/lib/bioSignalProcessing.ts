/**
 * Ultra-Precision BioSignal Fusion - Signal Processing Library
 * Implements thermal mapping, reflectance spectroscopy, and micro-pulse analysis
 */

export interface ThermalMap {
  estimatedTemperature: number; // Pseudo-thermal estimate in Celsius
  hotspots: { region: string; temperature: number }[];
  calibrationQuality: number; // 0-1
}

export interface ReflectanceSpectroscopy {
  hemoglobinIndex: number; // Normalized HI approximation
  melaninIndex: number; // Log-ratio based melanin estimate
  perfusionScore: number; // 0-100, from spectral features
  spectralQuality: number; // 0-1
}

export interface MicroPulseAnalysis {
  instantaneousFrequency: number; // Hz - micro-pulse frequency
  frequencyVariability: number; // Standard deviation
  lfHfRatio: number; // Autonomic stress indicator
  systolicDiastolicRatio: number; // Vascular elasticity proxy
  microPulseAnomalies: string[]; // Detected irregularities
}

export interface BioSignalFusionResult {
  thermal: ThermalMap;
  reflectance: ReflectanceSpectroscopy;
  microPulse: MicroPulseAnalysis;
  fusionConfidence: number; // 0-1
  clinicalFlags: string[];
}

/**
 * AI Thermal Mapping from RGB - Pseudo-thermal estimation
 * Uses normalized RGB values and temporal analysis to estimate temperature distribution
 */
export function estimateThermalMap(
  frames: { r: number; g: number; b: number }[],
  roi: { name: string; pixels: number[] }[]
): ThermalMap {
  // Baseline temperature calibration
  const baselineTemp = 36.5; // Normal body temperature
  
  // Calculate per-ROI spectral intensity
  const regionTemps = roi.map(region => {
    const regionFrames = frames.filter((_, idx) => region.pixels.includes(idx));
    const avgR = regionFrames.reduce((sum, f) => sum + f.r, 0) / regionFrames.length;
    const avgG = regionFrames.reduce((sum, f) => sum + f.g, 0) / regionFrames.length;
    const avgB = regionFrames.reduce((sum, f) => sum + f.b, 0) / regionFrames.length;
    
    // Thermal estimation: use red channel intensity as temperature proxy
    // Normalized: map [0,255] to [34°C, 38°C] range
    const normalizedR = avgR / 255;
    const estimatedTemp = baselineTemp - 2 + (normalizedR * 4);
    
    return {
      region: region.name,
      temperature: Math.max(34, Math.min(38, estimatedTemp)) // Clamp to physiological range
    };
  });
  
  // Calculate calibration quality based on temporal consistency
  let temporalVariance = 0;
  for (let i = 1; i < frames.length; i++) {
    const diff = Math.abs(frames[i].r - frames[i-1].r);
    temporalVariance += diff;
  }
  const calibrationQuality = Math.max(0, 1 - (temporalVariance / (frames.length * 255)));
  
  return {
    estimatedTemperature: regionTemps.reduce((sum, rt) => sum + rt.temperature, 0) / regionTemps.length,
    hotspots: regionTemps.sort((a, b) => b.temperature - a.temperature).slice(0, 3),
    calibrationQuality: Math.max(0, Math.min(1, calibrationQuality))
  };
}

/**
 * Skin Reflectance Spectroscopy - Extract spectral features from RGB
 * Approximates hemoglobin and melanin indices using color channel ratios
 */
export function analyzeReflectanceSpectroscopy(
  rgbFrames: { r: number; g: number; b: number }[]
): ReflectanceSpectroscopy {
  const avgR = rgbFrames.reduce((sum, f) => sum + f.r, 0) / rgbFrames.length;
  const avgG = rgbFrames.reduce((sum, f) => sum + f.g, 0) / rgbFrames.length;
  const avgB = rgbFrames.reduce((sum, f) => sum + f.b, 0) / rgbFrames.length;
  
  // Normalize to 0-1 range
  const normR = avgR / 255;
  const normG = avgG / 255;
  const normB = avgB / 255;
  
  // Hemoglobin Index approximation
  // Formula: HI ≈ (2R - G - B) / (R+G+B)
  const denominator = normR + normG + normB;
  const hemoglobinIndex = denominator > 0 
    ? ((2 * normR - normG - normB) / denominator) * 100  // Scale to 0-100
    : 50;
  
  // Melanin Index: Log-ratio based
  // Use R/G ratio as melanin proxy (melanin absorbs more red)
  const melaninRatio = normG > 0.01 ? normR / normG : 1;
  const melaninIndex = (Math.log(melaninRatio + 0.1) + 0.5) * 50; // Scale to ~0-100
  
  // Perfusion Score: derived from spectral balance
  // Higher perfusion = more balanced G channel
  const perfusionScore = (normG / Math.max(normR, normB, 0.01)) * 100;
  
  // Spectral quality: consistency across channels
  const spectralVariance = Math.abs(normR - normG) + Math.abs(normG - normB);
  const spectralQuality = Math.max(0, 1 - spectralVariance);
  
  return {
    hemoglobinIndex: Math.max(0, Math.min(100, hemoglobinIndex)),
    melaninIndex: Math.max(0, Math.min(100, melaninIndex)),
    perfusionScore: Math.max(0, Math.min(100, perfusionScore)),
    spectralQuality: Math.max(0, Math.min(1, spectralQuality))
  };
}

/**
 * Micro-Pulse Frequency Shift Analysis
 * Extracts PPG micro-features including frequency and HRV indicators
 */
export function analyzeMicroPulseFrequency(
  ppgTrace: number[],
  samplingRate: number = 30 // fps
): MicroPulseAnalysis {
  if (ppgTrace.length < 10) {
    return {
      instantaneousFrequency: 0,
      frequencyVariability: 0,
      lfHfRatio: 0,
      systolicDiastolicRatio: 1,
      microPulseAnomalies: ["Insufficient data for analysis"]
    };
  }
  
  // Find peaks (systolic peaks) for HR calculation
  const peaks: number[] = [];
  for (let i = 1; i < ppgTrace.length - 1; i++) {
    if (ppgTrace[i] > ppgTrace[i-1] && ppgTrace[i] > ppgTrace[i+1]) {
      peaks.push(i);
    }
  }
  
  // Calculate RR intervals (time between peaks)
  const rrIntervals: number[] = [];
  for (let i = 1; i < peaks.length; i++) {
    const interval = (peaks[i] - peaks[i-1]) / samplingRate; // Convert to seconds
    rrIntervals.push(interval);
  }
  
  // Mean HR and variability
  const meanInterval = rrIntervals.reduce((a, b) => a + b, 0) / Math.max(rrIntervals.length, 1);
  const hrVariability = rrIntervals.reduce((sum, interval) => 
    sum + Math.pow(interval - meanInterval, 2), 0) / Math.max(rrIntervals.length, 1);
  
  // Instantaneous frequency (HR in beats per minute)
  const instantaneousFrequency = meanInterval > 0 ? 60 / meanInterval : 0;
  const frequencyVariability = Math.sqrt(hrVariability);
  
  // Systolic/Diastolic analysis
  let systolicPeaks = 0, diastolicPeaks = 0;
  const threshold = ppgTrace.reduce((a, b) => a + b, 0) / ppgTrace.length;
  
  for (let i = 0; i < ppgTrace.length; i++) {
    if (ppgTrace[i] > threshold) systolicPeaks++;
    else diastolicPeaks++;
  }
  
  const systolicDiastolicRatio = diastolicPeaks > 0 ? systolicPeaks / diastolicPeaks : 1;
  
  // LF/HF Ratio approximation (simplified)
  // LF = low frequency (sympathetic), HF = high frequency (parasympathetic)
  const lfComponent = frequencyVariability * 0.4; // Simplified approximation
  const hfComponent = frequencyVariability * 0.6;
  const lfHfRatio = hfComponent > 0.01 ? lfComponent / hfComponent : 0;
  
  // Detect anomalies
  const anomalies: string[] = [];
  
  if (instantaneousFrequency < 50 || instantaneousFrequency > 100) {
    anomalies.push("Abnormal heart rate: " + Math.round(instantaneousFrequency) + " bpm");
  }
  
  if (frequencyVariability < 0.01) {
    anomalies.push("Very low HRV - possible reduced autonomic tone");
  }
  
  if (frequencyVariability > 0.2) {
    anomalies.push("Elevated HRV - possible stress or irregular rhythm");
  }
  
  if (lfHfRatio > 2.5) {
    anomalies.push("Elevated LF/HF ratio - sympathetic dominance detected");
  }
  
  return {
    instantaneousFrequency: Math.max(0, instantaneousFrequency),
    frequencyVariability: Math.max(0, frequencyVariability),
    lfHfRatio: Math.max(0, lfHfRatio),
    systolicDiastolicRatio: Math.max(0.5, Math.min(2, systolicDiastolicRatio)),
    microPulseAnomalies: anomalies
  };
}

/**
 * Multimodal Fusion - Combine thermal, reflectance, and micro-pulse signals
 */
export function fuseBioSignals(
  thermal: ThermalMap,
  reflectance: ReflectanceSpectroscopy,
  microPulse: MicroPulseAnalysis
): BioSignalFusionResult {
  // Calculate overall fusion confidence
  const confidenceScores = [
    thermal.calibrationQuality,
    reflectance.spectralQuality,
    microPulse.microPulseAnomalies.length === 0 ? 0.9 : 0.6 // Penalize if anomalies detected
  ];
  
  const fusionConfidence = confidenceScores.reduce((a, b) => a + b, 0) / confidenceScores.length;
  
  // Generate clinical flags based on fusion
  const clinicalFlags: string[] = [];
  
  if (thermal.estimatedTemperature < 35.5) {
    clinicalFlags.push("Low thermal signature - possible circulatory compromise");
  }
  if (thermal.estimatedTemperature > 37.5) {
    clinicalFlags.push("Elevated thermal signature - possible inflammation/fever");
  }
  
  if (reflectance.hemoglobinIndex < 30) {
    clinicalFlags.push("Low hemoglobin estimate - possible anemia");
  }
  if (reflectance.perfusionScore < 40) {
    clinicalFlags.push("Reduced perfusion - possible microvascular dysfunction");
  }
  
  clinicalFlags.push(...microPulse.microPulseAnomalies);
  
  return {
    thermal,
    reflectance,
    microPulse,
    fusionConfidence: Math.max(0, Math.min(1, fusionConfidence)),
    clinicalFlags: Array.from(new Set(clinicalFlags)) // Remove duplicates
  };
}

/**
 * Device Calibration - Per-device normalization for RGB consistency
 */
export function calibrateDevice(
  referenceFrames: { r: number; g: number; b: number }[],
  targetColorSpace: { r: number; g: number; b: number } = { r: 128, g: 128, b: 128 }
): (frame: { r: number; g: number; b: number }) => { r: number; g: number; b: number } {
  
  const avgR = referenceFrames.reduce((sum, f) => sum + f.r, 0) / referenceFrames.length;
  const avgG = referenceFrames.reduce((sum, f) => sum + f.g, 0) / referenceFrames.length;
  const avgB = referenceFrames.reduce((sum, f) => sum + f.b, 0) / referenceFrames.length;
  
  // Calculate correction factors
  const correctionR = targetColorSpace.r / Math.max(avgR, 1);
  const correctionG = targetColorSpace.g / Math.max(avgG, 1);
  const correctionB = targetColorSpace.b / Math.max(avgB, 1);
  
  // Return calibration function
  return (frame: { r: number; g: number; b: number }) => ({
    r: Math.max(0, Math.min(255, frame.r * correctionR)),
    g: Math.max(0, Math.min(255, frame.g * correctionG)),
    b: Math.max(0, Math.min(255, frame.b * correctionB))
  });
}
