import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, TrendingUp, TrendingDown, Activity, Calendar, Smartphone, Clock } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { Scan } from "@shared/schema";
import { format } from "date-fns";

export default function HistoryPage() {
  const { data: scans, isLoading } = useQuery<Scan[]>({
    queryKey: ["/api/scans"],
  });

  const getRiskBadgeColor = (score: number) => {
    if (score >= 80) return "bg-green-100 text-green-800 dark:bg-green-950 dark:text-green-300";
    if (score >= 50) return "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300";
    return "bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300";
  };

  const getTrendIndicator = (current: number, previous: number) => {
    if (current > previous) {
      return { icon: <TrendingUp className="w-4 h-4" />, color: "text-green-600 dark:text-green-400", text: `+${current - previous}` };
    } else if (current < previous) {
      return { icon: <TrendingDown className="w-4 h-4" />, color: "text-red-600 dark:text-red-400", text: `${current - previous}` };
    }
    return { icon: null, color: "text-muted-foreground", text: "No change" };
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-5xl">
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => window.history.back()}
            className="gap-2 hover-elevate active-elevate-2"
            data-testid="button-back"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </Button>
        </div>

        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold mb-2">Scan History</h1>
            <p className="text-muted-foreground text-lg">
              Your immune health scans tracked over the last 6 months
            </p>
          </div>
          <Link href="/scan">
            <Button size="lg" className="gap-2" data-testid="button-new-scan">
              <Activity className="w-5 h-5" />
              New Scan
            </Button>
          </Link>
        </div>

        {/* Stats */}
        {scans && scans.length > 0 && (
          <div className="grid md:grid-cols-4 gap-4 mb-8">
            <Card className="hover-elevate">
              <CardContent className="pt-6">
                <p className="text-sm font-medium text-muted-foreground mb-1">Total Scans</p>
                <p className="text-3xl font-bold">{scans.length}</p>
              </CardContent>
            </Card>
            <Card className="hover-elevate">
              <CardContent className="pt-6">
                <p className="text-sm font-medium text-muted-foreground mb-1">Average Score</p>
                <p className="text-3xl font-bold">
                  {Math.round(scans.reduce((sum, s) => sum + s.immunoScore, 0) / scans.length)}
                </p>
              </CardContent>
            </Card>
            <Card className="hover-elevate">
              <CardContent className="pt-6">
                <p className="text-sm font-medium text-muted-foreground mb-1">Latest Scan</p>
                <p className="text-sm font-semibold">
                  {format(new Date(scans[0].timestamp), "MMM dd, yyyy")}
                </p>
              </CardContent>
            </Card>
            <Card className="hover-elevate">
              <CardContent className="pt-6">
                <p className="text-sm font-medium text-muted-foreground mb-1">Retention</p>
                <p className="text-sm font-semibold flex items-center gap-1">
                  <Clock className="w-4 h-4" /> 6 months
                </p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Scans List */}
        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="h-6 bg-muted rounded w-1/3"></div>
                  <div className="h-4 bg-muted rounded w-1/4 mt-2"></div>
                </CardHeader>
                <CardContent>
                  <div className="h-24 bg-muted rounded"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : scans && scans.length > 0 ? (
          <div className="space-y-6">
            {scans.map((scan, index) => {
              const previousScan = scans[index + 1];
              const trend = previousScan ? getTrendIndicator(scan.immunoScore, previousScan.immunoScore) : null;

              return (
                <Card key={scan.id} className="hover-elevate overflow-hidden" data-testid={`card-scan-${scan.id}`}>
                  <CardContent className="p-0">
                    <div className="grid md:grid-cols-[200px,1fr,200px] gap-4 p-6 items-center">
                      {/* Left: ImmunoScore */}
                      <div>
                        <div className="flex items-center gap-3 mb-2">
                          <div className="text-3xl font-bold text-primary">{scan.immunoScore}</div>
                          <Badge className={getRiskBadgeColor(scan.immunoScore)} data-testid={`badge-risk-${scan.id}`}>
                            {scan.riskLevel}
                          </Badge>
                        </div>
                        {trend && trend.icon && (
                          <div className={`flex items-center gap-1 text-sm ${trend.color}`}>
                            {trend.icon}
                            <span className="font-medium">{trend.text}</span>
                          </div>
                        )}
                      </div>

                      {/* Middle: Date, Metrics */}
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <div className="flex items-center gap-2 mb-2">
                            <Calendar className="w-4 h-4 text-muted-foreground" />
                            <CardDescription>{format(new Date(scan.timestamp), "PPp")}</CardDescription>
                          </div>
                          <div className="flex items-center gap-2">
                            <Smartphone className="w-4 h-4" />
                            <Badge variant="outline" className="text-xs">
                              Smartphone Scan
                            </Badge>
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <p className="text-xs text-muted-foreground mb-1">HRV</p>
                            <p className="font-semibold">{scan.heartRateVariability?.toFixed(1) || "N/A"} ms</p>
                          </div>
                          <div>
                            <p className="text-xs text-muted-foreground mb-1">Perfusion</p>
                            <p className="font-semibold">{scan.perfusionIndex?.toFixed(1) || "N/A"}</p>
                          </div>
                        </div>
                      </div>

                      {/* Right: View Button */}
                      <div>
                        <Link href={`/results/${scan.immunoScore}`}>
                          <Button variant="outline" className="w-full hover-elevate active-elevate-2" data-testid={`button-view-${scan.id}`}>
                            View Details
                          </Button>
                        </Link>
                      </div>
                    </div>

                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <Card className="text-center py-12">
            <CardContent>
              <Activity className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
              <p className="text-muted-foreground mb-4">No scans yet</p>
              <p className="text-sm text-muted-foreground mb-6">
                Complete a scan to see your immune health history
              </p>
              <Link href="/scan">
                <Button className="gap-2" data-testid="button-start-first-scan">
                  <Activity className="w-4 h-4" />
                  Start Your First Scan
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}

        {/* Info Box */}
        <div className="mt-8 p-4 bg-primary/5 rounded-lg border border-primary/20">
          <p className="text-sm text-muted-foreground">
            <strong>Auto-Cleanup Policy:</strong> Scan records are automatically retained for 6 months from the scan date. Scans older than 6 months are automatically deleted to maintain database efficiency.
          </p>
        </div>
      </div>
    </div>
  );
}
