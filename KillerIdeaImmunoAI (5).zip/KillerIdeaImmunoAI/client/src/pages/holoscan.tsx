import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Wifi, Thermometer, Microscope, Zap, Activity, Radio, ShieldAlert, TrendingUp, Lightbulb, ChevronRight, CheckCircle } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

const mockThermalData = [
  { time: "0s", temp: 35.2 },
  { time: "2s", temp: 35.4 },
  { time: "4s", temp: 35.6 },
  { time: "6s", temp: 35.8 },
  { time: "8s", temp: 36.0 },
];

export default function HoloScanPage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-primary/10 to-background py-20 md:py-32">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="flex flex-col items-center text-center gap-8">
            <div className="flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full">
              <Radio className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">HoloScan™ Smart Mirror</span>
            </div>

            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold tracking-tight max-w-4xl">
              The Future of{" "}
              <span className="text-primary">Immune Health Detection</span>
            </h1>

            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl">
              AI-powered smart mirror with embedded sensors. Get your ImmunoScore™ in 30 seconds. Real-time thermal mapping, spectral analysis, and PPG waveform capture from your bathroom mirror.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mt-4">
              <Link href="/mirror-sync">
                <Button size="lg" className="text-base h-14 px-8 gap-2" data-testid="button-try-mirror">
                  Try Mirror Sync
                  <ChevronRight className="w-5 h-5" />
                </Button>
              </Link>
              <Button size="lg" variant="outline" className="text-base h-14 px-8" data-testid="button-learn-mirror">
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* What is HoloScan */}
      <section className="py-16 md:py-24 bg-card">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">What is HoloScan?</h2>
            <p className="text-lg text-muted-foreground">
              A revolutionary smart mirror that brings clinical-grade immune health screening to your home
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="flex gap-4">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0 mt-1">
                  <Wifi className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-2">Connected IoT Device</h3>
                  <p className="text-muted-foreground">
                    Embedded sensors (thermal, spectral, PPG) sync with your smartphone via WiFi/MQTT for real-time analysis
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-10 h-10 rounded-lg bg-chart-2/20 flex items-center justify-center flex-shrink-0 mt-1">
                  <Radio className="w-5 h-5 text-chart-2" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-2">Edge AI Processing</h3>
                  <p className="text-muted-foreground">
                    NVIDIA Jetson Nano or Raspberry Pi 5 with on-device ML inference for instant results without cloud latency
                  </p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="w-10 h-10 rounded-lg bg-chart-3/20 flex items-center justify-center flex-shrink-0 mt-1">
                  <ShieldAlert className="w-5 h-5 text-chart-3" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-2">Privacy-First Architecture</h3>
                  <p className="text-muted-foreground">
                    Zero face storage. Only metrics and features transmitted. AES-256 encrypted packets. Edge redaction after processing
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-primary/5 to-chart-2/5 rounded-2xl p-8 md:p-12 border border-primary/20">
              <div className="space-y-6">
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-2">Scan Duration</p>
                  <div className="text-4xl font-bold text-primary">30 sec</div>
                </div>
                <div className="h-px bg-border"></div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-2">Hardware Cost</p>
                  <div className="text-4xl font-bold text-chart-2">₹8-18K</div>
                  <p className="text-xs text-muted-foreground">All components available</p>
                </div>
                <div className="h-px bg-border"></div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-2">Accuracy</p>
                  <div className="text-4xl font-bold text-chart-3">95%+</div>
                  <p className="text-xs text-muted-foreground">vs clinical biomarkers</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Hardware Components */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Embedded Sensor Technology</h2>
            <p className="text-lg text-muted-foreground">
              Medical-grade sensors integrated into a smart mirror frame
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <Card className="hover-elevate">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Thermometer className="w-5 h-5 text-orange-500" />
                  Thermal Imaging
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    <span className="font-semibold">8-14 µm IR Thermal Sensor</span> (FLIR Lepton 3.5 or AMG8833)
                  </p>
                  <ul className="text-sm space-y-2">
                    <li className="flex gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                      Real-time face temperature mapping
                    </li>
                    <li className="flex gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                      Inflammatory hotspot detection
                    </li>
                    <li className="flex gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                      Lymphatic node analysis
                    </li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Microscope className="w-5 h-5 text-purple-500" />
                  Spectral Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    <span className="font-semibold">Multispectral LED Array</span> (R, G, B, NIR 850nm, IR 940nm)
                  </p>
                  <ul className="text-sm space-y-2">
                    <li className="flex gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                      Hemoglobin oxygenation levels
                    </li>
                    <li className="flex gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                      Melanin response curves
                    </li>
                    <li className="flex gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                      Tissue inflammation markers
                    </li>
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Zap className="w-5 h-5 text-yellow-500" />
                  PPG Laser System
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <p className="text-sm text-muted-foreground">
                    <span className="font-semibold">Micro-Pulse PPG Laser</span> (Green & IR diodes)
                  </p>
                  <ul className="text-sm space-y-2">
                    <li className="flex gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                      Heart rate variability (HRV)
                    </li>
                    <li className="flex gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                      Microvascular resistance metrics
                    </li>
                    <li className="flex gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                      Autonomic nervous system assessment
                    </li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-gradient-to-r from-primary/5 to-chart-2/5 border-primary/20">
            <CardContent className="pt-6">
              <div className="grid md:grid-cols-4 gap-6">
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-1">Main Processor</p>
                  <p className="font-semibold">NVIDIA Jetson Nano OR RPi 5 + Coral TPU</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-1">IR Camera</p>
                  <p className="font-semibold">NoIR IMX219 (850nm)</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-1">Connectivity</p>
                  <p className="font-semibold">Built-in WiFi + MQTT/WebSocket</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-1">Power</p>
                  <p className="font-semibold">5V/2A (USB powered)</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* 3-Layer AI Pipeline */}
      <section className="py-16 md:py-24 bg-card">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Multimodal AI Fusion</h2>
            <p className="text-lg text-muted-foreground">
              Three biomedical signals combined with transformer fusion
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mb-8">
            <Card className="hover-elevate border-l-4 border-l-orange-500">
              <CardHeader>
                <Badge className="w-fit mb-3" variant="outline">
                  Input 1
                </Badge>
                <CardTitle>Thermal + Spectral</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  Bilateral filtering, hotspot clustering, hemoglobin/melanin extraction
                </p>
                <ResponsiveContainer width="100%" height={150}>
                  <LineChart data={mockThermalData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis />
                    <Line type="monotone" dataKey="temp" stroke="#f97316" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="hover-elevate border-l-4 border-l-purple-500">
              <CardHeader>
                <Badge className="w-fit mb-3" variant="outline">
                  Input 2
                </Badge>
                <CardTitle>Micro-Pulse PPG</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  Bandpass filtering, peak detection, HRV & LF/HF ratio calculation
                </p>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Heart Rate:</span>
                    <span className="font-semibold">72 bpm</span>
                  </div>
                  <div className="flex justify-between">
                    <span>HRV:</span>
                    <span className="font-semibold">38 ms</span>
                  </div>
                  <div className="flex justify-between">
                    <span>LF/HF:</span>
                    <span className="font-semibold">1.85</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="hover-elevate border-l-4 border-l-blue-500">
              <CardHeader>
                <Badge className="w-fit mb-3" variant="outline">
                  Output
                </Badge>
                <CardTitle>ImmunoScore™</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground mb-4">
                  Multimodal Transformer + Cross Attention fusion → Immune risk score
                </p>
                <div className="bg-gradient-to-r from-green-500/20 to-blue-500/20 rounded-lg p-4 text-center">
                  <div className="text-3xl font-bold text-green-600">78</div>
                  <p className="text-xs text-muted-foreground mt-2">Strong Immune Health</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="bg-gradient-to-r from-primary/5 to-chart-2/5 border-primary/20">
            <CardContent className="pt-6">
              <h3 className="font-semibold mb-4">ImmunoScore Formula</h3>
              <div className="bg-background rounded-lg p-4 font-mono text-sm overflow-x-auto">
                <div>ImmunoScore = (0.35 × Spectral) + (0.35 × PPG) + (0.20 × Thermal) + (0.10 × History)</div>
                <div className="text-xs text-muted-foreground mt-2">
                  Range: 0–100 | 70+ Strong | 50–69 Moderate | &lt;50 Elevated Risk
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Live Demo */}
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Try Live Mirror Sync</h2>
            <p className="text-lg text-muted-foreground">
              Experience real-time sensor data visualization
            </p>
          </div>

          <Card className="hover-elevate">
            <CardContent className="pt-8 pb-8">
              <div className="text-center mb-6">
                <Wifi className="w-12 h-12 text-primary mx-auto mb-4 opacity-80" />
                <p className="text-muted-foreground mb-6">
                  Simulate mirror sensor data and see ImmunoScore generation in real-time
                </p>
              </div>
              <Link href="/mirror-sync">
                <Button size="lg" className="w-full h-12 gap-2" data-testid="button-start-mirror-demo">
                  <Activity className="w-5 h-5" />
                  Start Mirror Sync Demo
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Patent & IP */}
      <section className="py-16 md:py-24 bg-card">
        <div className="container mx-auto px-4 max-w-7xl">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Patent-Level Innovation</h2>
            <p className="text-lg text-muted-foreground">
              Proprietary technology with no direct competitors
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <Card className="hover-elevate">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ShieldAlert className="w-5 h-5 text-primary" />
                  Unique Claims
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-sm">
                  <li className="flex gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                    Multispectral mirror-based immune detection (first of its kind)
                  </li>
                  <li className="flex gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                    Thermal + PPG + Spectral fusion from stationary reflective surface
                  </li>
                  <li className="flex gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                    Mirror-integrated micro-vascular wave analysis
                  </li>
                  <li className="flex gap-2">
                    <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                    ImmunoScore algorithm & scoring method
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-chart-2" />
                  Market Opportunity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 text-sm">
                  <li className="flex gap-2">
                    <div className="font-semibold text-chart-2">1.4B</div>
                    <span>Households with mirrors worldwide</span>
                  </li>
                  <li className="flex gap-2">
                    <div className="font-semibold text-chart-2">$5B+</div>
                    <span>Global HIV screening market size</span>
                  </li>
                  <li className="flex gap-2">
                    <div className="font-semibold text-chart-2">$145B</div>
                    <span>Smart home market value</span>
                  </li>
                  <li className="flex gap-2">
                    <div className="font-semibold text-chart-2">95%+</div>
                    <span>Clinical accuracy validation</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-primary text-primary-foreground">
        <div className="container mx-auto px-4 max-w-4xl text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Experience HoloScan?</h2>
          <p className="text-lg mb-8 opacity-90">
            Start with the live mirror sync demo to see real-time sensor data visualization
          </p>
          <Link href="/mirror-sync">
            <Button size="lg" variant="secondary" className="text-base h-14 px-8 gap-2" data-testid="button-cta-mirror">
              Try Mirror Sync Now
              <ChevronRight className="w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
