import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight, Camera, Brain, TrendingUp, Zap, Shield, BarChart3, Smartphone, Lock, Gauge } from "lucide-react";
import { useLocation } from "wouter";

const features = [
  {
    icon: Camera,
    title: "Non-Invasive Camera Scanning",
    description: "10-second rear camera scan with automatic flash activation for accurate PPG signal capture",
    details: ["Facial spectral analysis", "Micro-vascular mapping", "Real-time signal quality indicator"]
  },
  {
    icon: Brain,
    title: "AI-Powered Analysis",
    description: "OpenAI GPT-5 multimodal analysis of camera frames for immune health assessment",
    details: ["Photoplethysmography (PPG)", "Thermal signatures", "Blood flow efficiency"]
  },
  {
    icon: BarChart3,
    title: "ImmunoScore™ (0-100)",
    description: "Comprehensive immune system integrity metric with visual progress indicators",
    details: ["7+ health metrics", "Risk level badges", "Detailed breakdowns"]
  },
  {
    icon: TrendingUp,
    title: "ImmunoGraph™ Predictions",
    description: "Temporal Transformer + Bayesian updating for immune trajectory forecasting",
    details: ["Next week/month predictions", "Decline pattern detection", "Recovery probability estimates"]
  },
  {
    icon: Zap,
    title: "Speed Optimization",
    description: "Client-side image compression reducing payload by 3-5x for faster uploads",
    details: ["4x smaller images", "Performance monitoring", "Dynamic quality adjustment"]
  },
  {
    icon: TrendingUp,
    title: "Bayesian Confidence Scoring",
    description: "Prediction confidence improves with more scans using statistical analysis",
    details: ["Scan count factor", "Variance analysis", "Trend consistency"]
  },
  {
    icon: Shield,
    title: "Health Metrics Tracking",
    description: "Monitor 7+ key immune health indicators across multiple scans",
    details: ["Heart Rate Variability", "Capillary Refill Time", "Perfusion Index", "Oxygen Saturation"]
  },
  {
    icon: Gauge,
    title: "Immune Reserve Power",
    description: "Estimated capacity of your immune system based on trends and velocity",
    details: ["Trend-based calculation", "Velocity acceleration", "Reserve forecasting"]
  },
  {
    icon: Lock,
    title: "Secure Data Storage",
    description: "PostgreSQL database persistence with encrypted session management",
    details: ["Neon database", "Drizzle ORM", "Express.js backend"]
  },
  {
    icon: Smartphone,
    title: "Mobile-First Design",
    description: "Responsive interface optimized for all screen sizes with dark/light mode",
    details: ["Medical-grade UI", "Accessibility compliance", "SF Pro Display typography"]
  }
];

export default function FeaturesPage() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted">
      <div className="container mx-auto px-4 py-12 max-w-6xl">
        {/* Header */}
        <div className="mb-16 text-center">
          <h1 className="text-5xl font-bold mb-4">ImmunoAI Features</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Revolutionary non-invasive immune health screening using AI-powered camera analysis and Bayesian predictions
          </p>
        </div>

        {/* Feature Grid */}
        <div className="grid md:grid-cols-2 gap-6 mb-16">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card key={index} className="hover-elevate active-elevate-2 transition-all">
                <CardHeader>
                  <div className="flex items-start gap-4">
                    <div className="p-3 bg-primary/10 rounded-lg">
                      <Icon className="w-6 h-6 text-primary" />
                    </div>
                    <div className="flex-1">
                      <CardTitle>{feature.title}</CardTitle>
                      <CardDescription className="mt-1">{feature.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {feature.details.map((detail, i) => (
                      <li key={i} className="flex items-center gap-2 text-sm">
                        <div className="w-1.5 h-1.5 rounded-full bg-primary/60"></div>
                        <span className="text-muted-foreground">{detail}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Key Metrics */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold mb-8">Key Capabilities</h2>
          <div className="grid md:grid-cols-4 gap-6">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Scan Duration</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-primary">10 sec</p>
                <p className="text-sm text-muted-foreground mt-1">Quick & convenient</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Health Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-primary">7+</p>
                <p className="text-sm text-muted-foreground mt-1">Comprehensive analysis</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Compression</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-primary">4x</p>
                <p className="text-sm text-muted-foreground mt-1">Smaller payload</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg">Confidence</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold text-primary">95%</p>
                <p className="text-sm text-muted-foreground mt-1">Max at 10 scans</p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Technology Stack */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold mb-8">Technology Stack</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Frontend</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• React + TypeScript</li>
                  <li>• Wouter routing</li>
                  <li>• TanStack Query</li>
                  <li>• Shadcn UI + Tailwind</li>
                  <li>• Recharts visualizations</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Backend</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• Express.js</li>
                  <li>• Node.js runtime</li>
                  <li>• Drizzle ORM</li>
                  <li>• PostgreSQL (Neon)</li>
                  <li>• Zod validation</li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-lg">AI & Analysis</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• OpenAI GPT-5</li>
                  <li>• Multimodal analysis</li>
                  <li>• Temporal Transformers</li>
                  <li>• Bayesian updating</li>
                  <li>• Pattern recognition</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* How It Works */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold mb-8">How It Works</h2>
          <div className="grid md:grid-cols-4 gap-4">
            {[
              { step: 1, title: "Scan", desc: "Position finger over rear camera" },
              { step: 2, title: "Analyze", desc: "AI processes PPG signals" },
              { step: 3, title: "Score", desc: "ImmunoScore generated (0-100)" },
              { step: 4, title: "Predict", desc: "ImmunoGraph forecasts trends" }
            ].map((item) => (
              <div key={item.step} className="flex flex-col">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold">
                    {item.step}
                  </div>
                  {item.step < 4 && <ArrowRight className="w-5 h-5 text-primary/40" />}
                </div>
                <h3 className="font-semibold text-lg mb-1">{item.title}</h3>
                <p className="text-sm text-muted-foreground">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
          <Button
            size="lg"
            className="gap-2"
            onClick={() => setLocation("/scan")}
            data-testid="button-start-scanning"
          >
            Start Scanning
            <ArrowRight className="w-4 h-4" />
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="gap-2"
            onClick={() => setLocation("/performance")}
            data-testid="button-view-performance"
          >
            View Performance Metrics
            <Zap className="w-4 h-4" />
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="gap-2"
            onClick={() => setLocation("/history")}
            data-testid="button-view-history"
          >
            View Scan History
            <TrendingUp className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
