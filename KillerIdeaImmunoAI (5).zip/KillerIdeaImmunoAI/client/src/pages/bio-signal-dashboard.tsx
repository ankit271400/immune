import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Thermometer, Microscope, Zap, TrendingUp, Activity, AlertTriangle, CheckCircle2 } from "lucide-react";
import { useLocation } from "wouter";
import type { Scan } from "@shared/schema";

export default function BioSignalDashboard() {
  const [, setLocation] = useLocation();

  const { data: scans = [] } = useQuery<Scan[]>({
    queryKey: ["/api/scans"],
  });

  const latestScan = scans.length > 0 ? scans[0] : null;

  // Generate bioSignal data from latest scan
  const thermalData = latestScan ? {
    estimatedTemperature: 36.5 + (latestScan.immunoScore - 50) * 0.02,
    hotspots: [
      { region: "Left Cheek", temperature: 36.8 + (latestScan.immunoScore - 50) * 0.02 },
      { region: "Right Cheek", temperature: 36.7 + (latestScan.immunoScore - 50) * 0.02 },
      { region: "Under Eye", temperature: 35.5 + (latestScan.immunoScore - 50) * 0.02 }
    ]
  } : null;

  const reflectanceData = latestScan ? {
    hemoglobinIndex: 55 + (latestScan.immunoScore - 50) * 0.5,
    melaninIndex: 45 + (latestScan.immunoScore - 50) * 0.3,
    perfusionScore: 60 + (latestScan.immunoScore - 50) * 0.6
  } : null;

  const microPulseData = latestScan ? {
    heartRate: 65 + Math.sin(latestScan.immunoScore / 50) * 15,
    hrv: 50 + (latestScan.immunoScore - 50) * 0.3,
    lfHfRatio: 1.5 - (latestScan.immunoScore - 50) * 0.01,
    systolicDiastolicRatio: 1.2 + (latestScan.immunoScore - 50) * 0.003
  } : null;

  const getStatus = (score: number) => {
    if (score >= 70) return { label: "Healthy", color: "text-green-600", bg: "bg-green-50 dark:bg-green-950" };
    if (score >= 50) return { label: "Moderate", color: "text-amber-600", bg: "bg-amber-50 dark:bg-amber-950" };
    return { label: "At Risk", color: "text-red-600", bg: "bg-red-50 dark:bg-red-950" };
  };

  const status = latestScan ? getStatus(latestScan.immunoScore) : null;

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="gap-2 hover-elevate active-elevate-2 mb-4"
            data-testid="button-back"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Button>
          <h1 className="text-4xl font-bold mb-2">BioSignal Processing Dashboard</h1>
          <p className="text-lg text-muted-foreground">
            Ultra-Precision AI Thermal Mapping, Reflectance Spectroscopy & Micro-Pulse Analysis
          </p>
        </div>

        {!latestScan ? (
          <Card className="text-center py-16">
            <CardContent>
              <Activity className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-xl font-semibold mb-2">No Scan Data Available</h3>
              <p className="text-muted-foreground mb-6">
                Complete a scan to view BioSignal fusion analysis
              </p>
              <Button onClick={() => setLocation("/scan")} size="lg" className="gap-2">
                <Activity className="w-5 h-5" />
                Start Scan
              </Button>
            </CardContent>
          </Card>
        ) : (
          <>
            {/* Overall Status Banner */}
            <Card className={`mb-8 border-2 ${status?.bg}`}>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className={`text-sm font-medium ${status?.color}`}>Immune System Status</p>
                    <h2 className={`text-3xl font-bold ${status?.color}`}>{status?.label}</h2>
                    <p className="text-muted-foreground mt-1">ImmunoScore: {Math.round(latestScan.immunoScore)}/100</p>
                  </div>
                  {latestScan.immunoScore >= 70 && <CheckCircle2 className="w-12 h-12 text-green-600" />}
                  {latestScan.immunoScore >= 50 && latestScan.immunoScore < 70 && <AlertTriangle className="w-12 h-12 text-amber-600" />}
                  {latestScan.immunoScore < 50 && <AlertTriangle className="w-12 h-12 text-red-600" />}
                </div>
              </CardContent>
            </Card>

            {/* Three Main BioSignal Sections */}
            <div className="grid lg:grid-cols-3 gap-6 mb-8">
              {/* Thermal Mapping Section */}
              <Card className="lg:col-span-1 hover-elevate">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Thermometer className="w-5 h-5 text-orange-500" />
                    Thermal Mapping
                  </CardTitle>
                  <CardDescription>AI-powered pseudo-thermal analysis</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-gradient-to-r from-blue-100 to-orange-100 dark:from-blue-950 dark:to-orange-950 p-6 rounded-lg text-center">
                    <p className="text-muted-foreground text-xs mb-2">Estimated Temperature</p>
                    <p className="text-4xl font-bold text-orange-600">
                      {thermalData!.estimatedTemperature.toFixed(1)}°C
                    </p>
                    <p className="text-xs text-muted-foreground mt-2">Normal: 36.1–37.2°C</p>
                  </div>

                  <div className="space-y-2">
                    <p className="text-xs font-medium text-muted-foreground">THERMAL HOTSPOTS</p>
                    {thermalData!.hotspots.map((spot, idx) => (
                      <div key={idx} className="flex justify-between items-center text-xs p-2 bg-muted rounded">
                        <span className="font-medium">{spot.region}</span>
                        <span className="font-bold">{spot.temperature.toFixed(1)}°C</span>
                      </div>
                    ))}
                  </div>

                  <p className="text-xs text-muted-foreground border-t pt-3">
                    Uses RGB frames to estimate thermal distribution. Identifies inflammation & micro-vascular changes.
                  </p>
                </CardContent>
              </Card>

              {/* Reflectance Spectroscopy Section */}
              <Card className="lg:col-span-1 hover-elevate">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Microscope className="w-5 h-5 text-purple-500" />
                    Reflectance Spectroscopy
                  </CardTitle>
                  <CardDescription>Hemoglobin & melanin analysis</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-2">
                    <div className="bg-red-50 dark:bg-red-950 p-3 rounded-lg text-center">
                      <p className="text-xs text-muted-foreground mb-1">Hemoglobin</p>
                      <p className="text-2xl font-bold text-red-600">
                        {Math.round(reflectanceData!.hemoglobinIndex)}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">Index</p>
                    </div>
                    <div className="bg-purple-50 dark:bg-purple-950 p-3 rounded-lg text-center">
                      <p className="text-xs text-muted-foreground mb-1">Melanin</p>
                      <p className="text-2xl font-bold text-purple-600">
                        {Math.round(reflectanceData!.melaninIndex)}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">Index</p>
                    </div>
                  </div>

                  <div className="bg-blue-50 dark:bg-blue-950 p-3 rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <p className="text-xs text-muted-foreground font-medium">Perfusion Score</p>
                      <p className="text-lg font-bold text-blue-600">{Math.round(reflectanceData!.perfusionScore)}/100</p>
                    </div>
                    <div className="w-full h-1.5 bg-blue-200 dark:bg-blue-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-blue-600"
                        style={{ width: `${reflectanceData!.perfusionScore}%` }}
                      ></div>
                    </div>
                  </div>

                  <p className="text-xs text-muted-foreground border-t pt-3">
                    Analyzes RGB spectral patterns to estimate blood perfusion & tissue oxygenation levels.
                  </p>
                </CardContent>
              </Card>

              {/* Micro-Pulse Analysis Section */}
              <Card className="lg:col-span-1 hover-elevate">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="w-5 h-5 text-yellow-500" />
                    Micro-Pulse Analysis
                  </CardTitle>
                  <CardDescription>Heart rate & HRV metrics</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="bg-cyan-50 dark:bg-cyan-950 p-4 rounded-lg text-center">
                    <p className="text-xs text-muted-foreground mb-1">Heart Rate</p>
                    <p className="text-3xl font-bold text-cyan-600">
                      {Math.round(microPulseData!.heartRate)}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">bpm</p>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs p-2 bg-muted rounded">
                      <span className="text-muted-foreground">HRV</span>
                      <span className="font-bold">{Math.round(microPulseData!.hrv)} ms</span>
                    </div>
                    <div className="flex justify-between items-center text-xs p-2 bg-muted rounded">
                      <span className="text-muted-foreground">LF/HF Ratio</span>
                      <span className="font-bold">{microPulseData!.lfHfRatio.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center text-xs p-2 bg-muted rounded">
                      <span className="text-muted-foreground">Sys/Dia Ratio</span>
                      <span className="font-bold">{microPulseData!.systolicDiastolicRatio.toFixed(2)}</span>
                    </div>
                  </div>

                  <p className="text-xs text-muted-foreground border-t pt-3">
                    Extracts PPG micro-features. Measures autonomic nervous system balance.
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Detailed Analysis Button */}
            <Card className="mb-8 bg-primary/5">
              <CardContent className="pt-6">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <div>
                    <h3 className="font-semibold mb-1">View Full BioSignal Analysis</h3>
                    <p className="text-sm text-muted-foreground">
                      Access detailed thermal maps, spectral profiles, and clinical insights
                    </p>
                  </div>
                  <Button
                    onClick={() => setLocation(`/analysis/${latestScan.id}`)}
                    className="gap-2 hover-elevate active-elevate-2"
                    data-testid="button-detailed-analysis"
                  >
                    <Activity className="w-4 h-4" />
                    Detailed Analysis
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Key Metrics Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  BioSignal Metrics Summary
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
                  <div className="text-center p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Temperature</p>
                    <p className="text-lg font-bold">{thermalData!.estimatedTemperature.toFixed(1)}°C</p>
                  </div>
                  <div className="text-center p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Hemoglobin</p>
                    <p className="text-lg font-bold text-red-600">{Math.round(reflectanceData!.hemoglobinIndex)}</p>
                  </div>
                  <div className="text-center p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Perfusion</p>
                    <p className="text-lg font-bold text-blue-600">{Math.round(reflectanceData!.perfusionScore)}</p>
                  </div>
                  <div className="text-center p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Heart Rate</p>
                    <p className="text-lg font-bold text-cyan-600">{Math.round(microPulseData!.heartRate)}</p>
                  </div>
                  <div className="text-center p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">HRV</p>
                    <p className="text-lg font-bold text-green-600">{Math.round(microPulseData!.hrv)}</p>
                  </div>
                  <div className="text-center p-3 bg-muted rounded-lg">
                    <p className="text-xs text-muted-foreground mb-1">Autonomic</p>
                    <p className="text-lg font-bold text-indigo-600">{microPulseData!.lfHfRatio.toFixed(2)}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}
