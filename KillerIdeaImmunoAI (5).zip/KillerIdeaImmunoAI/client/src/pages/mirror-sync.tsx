import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { iotService } from "@/lib/iotService";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts";
import { Wifi, Activity, Thermometer, Zap, TrendingUp, CheckCircle } from "lucide-react";
import type { MirrorSensorData } from "@shared/schema";

const MirrorSyncPage = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [sensorData, setSensorData] = useState<MirrorSensorData | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [ppgHistory, setPpgHistory] = useState<Array<{ time: number; value: number }>>([]);

  const startScan = async () => {
    try {
      const newSessionId = await iotService.connectToMirror("HoloScan-Mirror-001");
      setSessionId(newSessionId);
      setIsScanning(true);
      setPpgHistory([]);

      // Start mock sensor stream
      iotService.startMockSensorStream(newSessionId);

      // Poll for sensor data
      const pollInterval = setInterval(async () => {
        const session = iotService.getSessionData(newSessionId);
        if (session?.liveData) {
          setSensorData(session.liveData);

          // Update PPG history
          if (session.liveData.ppgWaveform.length > 0) {
            const newHistory = session.liveData.ppgWaveform.slice(-60).map((val, idx) => ({
              time: idx,
              value: val,
            }));
            setPpgHistory(newHistory);
          }

          if (session.status === "complete") {
            setIsScanning(false);
            clearInterval(pollInterval);

            // Save to history
            if (session.liveData.immunoScore) {
              try {
                await fetch("/api/mirror/sync", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({
                    deviceId: "HoloScan-Mirror-001",
                    sessionId: newSessionId,
                    sensorData: session.liveData,
                  }),
                });
                
                // Invalidate history cache
                queryClient.invalidateQueries({ queryKey: ["/api/mirror/history"] });
                toast({
                  title: "Scan saved",
                  description: "Your mirror scan has been saved to history",
                });
              } catch (error) {
                console.error("Failed to save scan:", error);
              }
            }
          }
        }
      }, 500);

      return () => clearInterval(pollInterval);
    } catch (error) {
      console.error("Failed to start scan:", error);
      setIsScanning(false);
    }
  };

  const stopScan = () => {
    if (sessionId) {
      iotService.disconnect(sessionId);
      setSessionId(null);
      setSensorData(null);
      setIsScanning(false);
    }
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Wifi className="w-6 h-6 text-primary" />
            </div>
            <h1 className="text-4xl font-bold">Mirror Sync Live</h1>
          </div>
          <p className="text-lg text-muted-foreground">
            Real-time sensor data from HoloScan smart mirror
          </p>
        </div>

        {/* Connection Status */}
        <Card className="mb-6 border-primary/20 bg-primary/5">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`w-3 h-3 rounded-full ${isScanning ? "bg-green-500 animate-pulse" : "bg-gray-400"}`} />
                <div>
                  <p className="font-semibold">
                    {isScanning ? "Scanning..." : "Ready"}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {sessionId ? `Session: ${sessionId}` : "No active session"}
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button
                  onClick={startScan}
                  disabled={isScanning}
                  className="gap-2"
                  data-testid="button-start-mirror-scan"
                >
                  <Activity className="w-4 h-4" />
                  {isScanning ? "Scanning..." : "Start Scan"}
                </Button>
                <Button
                  onClick={stopScan}
                  disabled={!isScanning}
                  variant="outline"
                  data-testid="button-stop-mirror-scan"
                >
                  Stop
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Live Data Display */}
        {sensorData && (
          <>
            {/* Immune Score */}
            {sensorData.immunoScore && (
              <div className="mb-6 p-6 bg-gradient-to-br from-green-500/10 to-blue-500/10 rounded-lg border border-green-500/20">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground mb-2">ImmunoScore</p>
                    <div className="text-5xl font-bold">{Math.round(sensorData.immunoScore)}</div>
                  </div>
                  <CheckCircle className="w-12 h-12 text-green-500" />
                </div>
              </div>
            )}

            {/* Three Main Signal Cards */}
            <div className="grid md:grid-cols-3 gap-6 mb-6">
              {/* Thermal */}
              <Card className="hover-elevate">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Thermometer className="w-5 h-5 text-orange-500" />
                    Thermal Mapping
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="mb-4">
                    <p className="text-3xl font-bold">{sensorData.thermalTemp.toFixed(1)}°C</p>
                    <p className="text-sm text-muted-foreground">Core Temperature</p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-xs font-semibold text-muted-foreground">Hotspots:</p>
                    {sensorData.thermalHotspots.map((spot, idx) => (
                      <div key={idx} className="flex justify-between text-sm">
                        <span>{spot.region}</span>
                        <span className="font-semibold">{spot.temp.toFixed(1)}°C</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Spectral */}
              <Card className="hover-elevate">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <TrendingUp className="w-5 h-5 text-purple-500" />
                    Spectral Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Hemoglobin</span>
                        <span className="font-semibold">{sensorData.spectralData.hemoglobin.toFixed(0)}</span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div
                          className="h-full bg-red-500"
                          style={{ width: `${sensorData.spectralData.hemoglobin}%` }}
                        />
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Melanin</span>
                        <span className="font-semibold">{sensorData.spectralData.melanin.toFixed(0)}</span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div
                          className="h-full bg-amber-700"
                          style={{ width: `${sensorData.spectralData.melanin}%` }}
                        />
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Perfusion</span>
                        <span className="font-semibold">{sensorData.spectralData.perfusion.toFixed(0)}</span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div
                          className="h-full bg-blue-500"
                          style={{ width: `${sensorData.spectralData.perfusion}%` }}
                        />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Micro-Pulse */}
              <Card className="hover-elevate">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center gap-2 text-lg">
                    <Zap className="w-5 h-5 text-yellow-500" />
                    Micro-Pulse
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <p className="text-sm text-muted-foreground">Heart Rate</p>
                      <p className="text-2xl font-bold">{Math.round(sensorData.heartRate)} bpm</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">HRV</p>
                      <p className="text-lg font-semibold">{sensorData.hrv.toFixed(1)} ms</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">LF/HF Ratio</p>
                      <p className="text-lg font-semibold">{sensorData.lfHfRatio.toFixed(2)}</p>
                    </div>
                    <Badge
                      variant={sensorData.sigQuality === "excellent" ? "default" : "secondary"}
                      data-testid={`badge-signal-quality-${sensorData.sigQuality}`}
                    >
                      Signal: {sensorData.sigQuality}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* PPG Waveform Chart */}
            {ppgHistory.length > 0 && (
              <Card className="hover-elevate">
                <CardHeader>
                  <CardTitle>PPG Waveform (Last 60 seconds)</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <AreaChart data={ppgHistory}>
                      <defs>
                        <linearGradient id="colorPPG" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#22c55e" stopOpacity={0.8} />
                          <stop offset="95%" stopColor="#22c55e" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" />
                      <YAxis />
                      <Tooltip />
                      <Area
                        type="monotone"
                        dataKey="value"
                        stroke="#22c55e"
                        fillOpacity={1}
                        fill="url(#colorPPG)"
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            )}
          </>
        )}

        {!isScanning && !sensorData && (
          <Card className="text-center py-12">
            <CardContent>
              <Wifi className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
              <p className="text-muted-foreground mb-4">No active mirror connection</p>
              <Button onClick={startScan} data-testid="button-connect-mirror">
                Connect to Smart Mirror
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default MirrorSyncPage;
