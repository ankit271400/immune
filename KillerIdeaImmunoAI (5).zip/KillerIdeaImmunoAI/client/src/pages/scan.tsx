import { useState, useRef, useCallback, useEffect } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Camera, AlertCircle, Activity, CheckCircle2, ArrowLeft, Info, Smartphone, Hand, Zap } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { compressImage, getDynamicCompressionOptions, PerformanceMonitor } from "@/lib/imageOptimization";
import type { ScanAnalysisResponse } from "@shared/schema";

export default function ScanPage() {
  const [, setLocation] = useLocation();
  const [scanning, setScanning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [cameraReady, setCameraReady] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [showInstructions, setShowInstructions] = useState(true);
  const [signalQuality, setSignalQuality] = useState<"poor" | "good" | "excellent">("good");
  const [processingStatus, setProcessingStatus] = useState<string>("");
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const framesCaptured = useRef<string[]>([]);
  const performanceMonitor = useRef<PerformanceMonitor>(new PerformanceMonitor());

  const enableTorch = useCallback(async (enable: boolean) => {
    if (!streamRef.current) return;
    
    const videoTrack = streamRef.current.getVideoTracks()[0];
    if (videoTrack && 'getCapabilities' in videoTrack) {
      const capabilities = videoTrack.getCapabilities() as any;
      
      if (capabilities.torch) {
        try {
          await videoTrack.applyConstraints({
            advanced: [{ torch: enable } as any]
          });
        } catch (error) {
          console.log("Torch not available on this device:", error);
        }
      }
    }
  }, []);

  useEffect(() => {
    return () => {
      if (streamRef.current) {
        const videoTrack = streamRef.current.getVideoTracks()[0];
        if (videoTrack && 'getCapabilities' in videoTrack) {
          const capabilities = videoTrack.getCapabilities() as any;
          if (capabilities.torch) {
            try {
              videoTrack.applyConstraints({
                advanced: [{ torch: false } as any]
              });
            } catch (error) {
              console.log("Error disabling torch:", error);
            }
          }
        }
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const analyzeScanMutation = useMutation({
    mutationFn: async (data: { imageData: string; duration: number; frames: number }) => {
      performanceMonitor.current.markUploadStart();
      const response = await apiRequest("POST", "/api/scans/analyze", data);
      performanceMonitor.current.markUploadComplete();
      const result = await response.json() as ScanAnalysisResponse;
      performanceMonitor.current.markAIProcessingComplete();
      
      const metrics = performanceMonitor.current.getMetrics();
      console.log(performanceMonitor.current.getSummary());
      console.log("Speed: ", (metrics.totalTime / 1000).toFixed(2), "seconds");
      
      return result;
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/scans"] });
      setLocation(`/results/${data.immunoScore}`);
    },
    onError: (error: Error) => {
      enableTorch(false);
      setCameraError(error.message || "Analysis failed. Please try again.");
      setScanning(false);
      setProgress(0);
      setProcessingStatus("");
    },
  });

  const startCamera = useCallback(async () => {
    try {
      setCameraError(null);
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { 
            facingMode: { ideal: "environment" }, 
            width: { ideal: 1280 }, 
            height: { ideal: 720 }
          },
        });
        
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          streamRef.current = stream;
          setCameraReady(true);
          setShowInstructions(false);
          performanceMonitor.current.markCameraReady();
        }
      } catch (rearCameraError) {
        console.warn("Rear camera unavailable, trying any camera:", rearCameraError);
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { width: { ideal: 1280 }, height: { ideal: 720 } }
        });
        
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          streamRef.current = stream;
          setCameraReady(true);
          setShowInstructions(false);
          performanceMonitor.current.markCameraReady();
        }
      }
    } catch (error) {
      setCameraError("Unable to access camera. Please grant camera permissions and refresh the page.");
      console.error("Camera error:", error);
    }
  }, []);

  const captureFrame = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return null;
    
    const video = videoRef.current;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    
    if (!ctx) return null;
    
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    ctx.drawImage(video, 0, 0);
    
    return canvas.toDataURL("image/jpeg", 0.8);
  }, []);

  const startScan = useCallback(async () => {
    if (!cameraReady) {
      await startCamera();
      return;
    }

    setScanning(true);
    setProgress(0);
    framesCaptured.current = [];

    await enableTorch(true);

    const scanDuration = 10000;
    const frameInterval = 200;
    const startTime = Date.now();

    const interval = setInterval(() => {
      const elapsed = Date.now() - startTime;
      const currentProgress = Math.min((elapsed / scanDuration) * 100, 100);
      setProgress(currentProgress);

      if (currentProgress < 30) {
        setSignalQuality("poor");
      } else if (currentProgress < 70) {
        setSignalQuality("good");
      } else {
        setSignalQuality("excellent");
      }

      const frame = captureFrame();
      if (frame) {
        framesCaptured.current.push(frame);
      }

      if (elapsed >= scanDuration) {
        clearInterval(interval);
        setProgress(100);
        performanceMonitor.current.markFramesCaptured();
        
        enableTorch(false);
        
        const lastFrame = framesCaptured.current[framesCaptured.current.length - 1] || "";
        
        setProcessingStatus("Optimizing image...");
        
        const compressionOptions = getDynamicCompressionOptions();
        
        compressImage(lastFrame, compressionOptions).then(async (result) => {
          performanceMonitor.current.markCompressionComplete();
          
          console.log(`Image compressed: ${result.originalSize} → ${result.compressedSize} bytes (${result.compressionRatio.toFixed(2)}x smaller in ${result.processingTimeMs.toFixed(0)}ms)`);
          
          setProcessingStatus("Uploading to AI...");
          
          analyzeScanMutation.mutate({
            imageData: result.dataUrl,
            duration: scanDuration,
            frames: framesCaptured.current.length,
          });
        }).catch((error) => {
          console.error("Compression failed, using original:", error);
          setProcessingStatus("Uploading to AI...");
          analyzeScanMutation.mutate({
            imageData: lastFrame,
            duration: scanDuration,
            frames: framesCaptured.current.length,
          });
        });
      }
    }, frameInterval);
  }, [cameraReady, captureFrame, analyzeScanMutation, startCamera, enableTorch]);

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="gap-2 hover-elevate active-elevate-2"
            data-testid="button-back"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </Button>
        </div>

        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-3">Immune Health Scan</h1>
          <p className="text-muted-foreground text-lg">
            Position your camera and follow the instructions for accurate results
          </p>
        </div>

        {showInstructions && (
          <Alert className="mb-6 bg-primary/5 border-primary/20">
            <Info className="w-4 h-4 text-primary" />
            <AlertDescription className="text-sm">
              <strong>Before you begin:</strong> Place your index finger gently over the rear camera lens and flashlight. Keep steady contact throughout the 10-second scan for accurate micro-vascular analysis.
            </AlertDescription>
          </Alert>
        )}

        {cameraError && (
          <Alert className="mb-6" variant="destructive">
            <AlertCircle className="w-4 h-4" />
            <AlertDescription>{cameraError}</AlertDescription>
          </Alert>
        )}

        <Card className="mb-6">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Camera className="w-5 h-5" />
              Camera View
            </CardTitle>
            <CardDescription>
              {!cameraReady
                ? "Click 'Start Scan' to enable your camera"
                : scanning
                ? "Scan in progress - hold still"
                : "Camera ready - click 'Start Scan' when ready"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="relative aspect-video bg-muted rounded-lg overflow-hidden">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
                data-testid="video-camera"
              />
              <canvas ref={canvasRef} className="hidden" />
              
              {!cameraReady && (
                <div className="absolute inset-0 flex items-center justify-center bg-muted">
                  <div className="text-center">
                    <Camera className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-muted-foreground">Camera not active</p>
                  </div>
                </div>
              )}

              {cameraReady && !scanning && (
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="relative">
                    <div className="w-48 h-48 rounded-full border-4 border-primary/30 border-dashed flex items-center justify-center">
                      <Hand className="w-20 h-20 text-primary/50" />
                    </div>
                    <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-background/90 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap">
                      Cover camera with fingertip
                    </div>
                  </div>
                </div>
              )}

              {scanning && (
                <>
                  <div className="absolute inset-0 border-4 border-primary animate-pulse pointer-events-none"></div>
                  <div className="absolute top-4 right-4 bg-background/90 px-3 py-2 rounded-lg">
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${
                        signalQuality === "excellent" ? "bg-green-500 animate-pulse" :
                        signalQuality === "good" ? "bg-yellow-500 animate-pulse" :
                        "bg-red-500 animate-pulse"
                      }`}></div>
                      <span className="text-xs font-medium capitalize">{signalQuality} Signal</span>
                    </div>
                  </div>
                </>
              )}
            </div>

            {scanning && (
              <div className="mt-6 space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Scanning progress</span>
                  <span className="font-medium">{Math.round(progress)}%</span>
                </div>
                <Progress value={progress} className="h-2" data-testid="progress-scan" />
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Activity className="w-4 h-4 animate-pulse text-primary" />
                  <span>Analyzing micro-vascular patterns...</span>
                </div>
              </div>
            )}
            
            {processingStatus && (
              <div className="mt-6 space-y-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Zap className="w-4 h-4 animate-pulse text-primary" />
                  <span data-testid="text-processing-status">{processingStatus}</span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        <div className="flex flex-col sm:flex-row gap-4">
          <Button
            size="lg"
            onClick={startScan}
            disabled={scanning || analyzeScanMutation.isPending}
            className="flex-1 gap-2 h-14"
            data-testid="button-start-scan"
          >
            {scanning || analyzeScanMutation.isPending ? (
              <>
                <Activity className="w-5 h-5 animate-pulse" />
                {analyzeScanMutation.isPending ? "Analyzing..." : "Scanning..."}
              </>
            ) : (
              <>
                <CheckCircle2 className="w-5 h-5" />
                {cameraReady ? "Start Scan" : "Enable Camera & Start"}
              </>
            )}
          </Button>
        </div>

        <div className="mt-8 grid sm:grid-cols-3 gap-4">
          <Card className="bg-primary/5">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Duration</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">10 sec</p>
            </CardContent>
          </Card>

          <Card className="bg-chart-2/10">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Metrics</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">7+</p>
            </CardContent>
          </Card>

          <Card className="bg-chart-3/10">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Accuracy</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-2xl font-bold">AI-Powered</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
