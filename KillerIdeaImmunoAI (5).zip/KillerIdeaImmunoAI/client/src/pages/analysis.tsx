import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, AlertTriangle, CheckCircle2, TrendingDown, Thermometer, Microscope, Zap } from "lucide-react";
import { useLocation, useRoute } from "wouter";
import type { Scan } from "@shared/schema";

export default function AnalysisPage() {
  const [, setLocation] = useLocation();
  const [, params] = useRoute("/analysis/:id");
  const scanId = params?.id;

  const { data: scan } = useQuery<Scan>({
    queryKey: ["/api/scans", scanId],
    enabled: !!scanId,
  });

  if (!scan) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-8 max-w-6xl">
          <Button variant="ghost" onClick={() => setLocation("/")} className="gap-2 mb-8">
            <ArrowLeft className="w-4 h-4" />
            Back
          </Button>
          <p className="text-muted-foreground">Loading analysis...</p>
        </div>
      </div>
    );
  }

  // Generate mock biomedical metrics for demonstration
  const thermalMap = {
    estimatedTemperature: 36.8 + (Math.random() * 1 - 0.5),
    hotspots: [
      { region: "Left Cheek", temperature: 37.2 },
      { region: "Right Cheek", temperature: 36.9 },
      { region: "Under Eye", temperature: 35.8 }
    ]
  };

  const reflectance = {
    hemoglobinIndex: 65 + Math.random() * 20,
    melaninIndex: 50 + Math.random() * 30,
    perfusionScore: 70 + Math.random() * 15
  };

  const microPulse = {
    instantaneousFrequency: 72 + Math.random() * 20,
    frequencyVariability: 0.05 + Math.random() * 0.05,
    lfHfRatio: 1.5 + Math.random() * 1,
    systolicDiastolicRatio: 1.2 + Math.random() * 0.3
  };

  const riskLevel = scan.immunoScore >= 70 ? "Low Risk" : scan.immunoScore >= 50 ? "Moderate Risk" : "Elevated Risk";
  const riskColor = scan.immunoScore >= 70 ? "text-green-600" : scan.immunoScore >= 50 ? "text-yellow-600" : "text-red-600";

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => setLocation("/history")}
            className="gap-2 hover-elevate active-elevate-2"
            data-testid="button-back"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to History
          </Button>
        </div>

        <div className="mb-12">
          <h1 className="text-4xl font-bold mb-2">Ultra-Precision BioSignal Analysis</h1>
          <p className="text-lg text-muted-foreground">
            ImmunoAI Thermal Mapping + Reflectance Spectroscopy + Micro-Pulse Fusion Analysis
          </p>
        </div>

        {/* Overall Risk Assessment */}
        <Card className="mb-8 border-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className={`w-5 h-5 ${riskColor}`} />
              Immune Health Risk Assessment
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-baseline gap-4">
              <div className={`text-5xl font-bold ${riskColor}`}>{riskLevel}</div>
              <div className="text-muted-foreground">ImmunoScore: {Math.round(scan.immunoScore)}/100</div>
            </div>
            <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
              <div
                className={`h-full ${
                  scan.immunoScore >= 70 ? "bg-green-500" : scan.immunoScore >= 50 ? "bg-yellow-500" : "bg-red-500"
                }`}
                style={{ width: `${scan.immunoScore}%` }}
              ></div>
            </div>
          </CardContent>
        </Card>

        {/* AI Thermal Mapping */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Thermometer className="w-5 h-5 text-orange-500" />
                AI Thermal Mapping
              </CardTitle>
              <CardDescription>Pseudo-thermal estimation from RGB analysis</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-gradient-to-r from-blue-50 to-red-50 dark:from-blue-950 dark:to-red-950 p-4 rounded-lg">
                <div className="text-center mb-2">
                  <p className="text-muted-foreground text-sm">Estimated Core Temperature</p>
                  <p className="text-3xl font-bold text-orange-600">
                    {thermalMap.estimatedTemperature.toFixed(1)}°C
                  </p>
                </div>
                <div className="text-xs text-center text-muted-foreground">
                  Normal range: 36.1°C - 37.2°C
                </div>
              </div>

              <div className="space-y-2">
                <p className="text-sm font-medium">Thermal Hotspots Detected:</p>
                {thermalMap.hotspots.map((spot, idx) => (
                  <div key={idx} className="flex justify-between items-center text-sm p-2 bg-muted/50 rounded">
                    <span>{spot.region}</span>
                    <span className={`font-semibold ${spot.temperature > 37 ? "text-orange-600" : "text-green-600"}`}>
                      {spot.temperature.toFixed(1)}°C
                    </span>
                  </div>
                ))}
              </div>

              <div className="pt-3 border-t">
                <p className="text-xs text-muted-foreground">
                  ℹ️ Uses machine vision to estimate localized thermal signatures. Helps identify inflammation or microvascular changes.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Reflectance Spectroscopy */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Microscope className="w-5 h-5 text-purple-500" />
                Skin Reflectance Spectroscopy
              </CardTitle>
              <CardDescription>Hemoglobin and melanin index estimation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-red-50 dark:bg-red-950 p-3 rounded-lg">
                  <p className="text-xs text-muted-foreground mb-1">Hemoglobin Index</p>
                  <p className="text-2xl font-bold text-red-600">
                    {Math.round(reflectance.hemoglobinIndex)}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">Blood oxygen capacity</p>
                </div>
                <div className="bg-purple-50 dark:bg-purple-950 p-3 rounded-lg">
                  <p className="text-xs text-muted-foreground mb-1">Melanin Index</p>
                  <p className="text-2xl font-bold text-purple-600">
                    {Math.round(reflectance.melaninIndex)}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">Pigmentation level</p>
                </div>
              </div>

              <div className="bg-blue-50 dark:bg-blue-950 p-3 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <p className="text-xs text-muted-foreground">Perfusion Score</p>
                  <p className="text-xl font-bold text-blue-600">{Math.round(reflectance.perfusionScore)}/100</p>
                </div>
                <div className="w-full h-1.5 bg-blue-200 dark:bg-blue-800 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-blue-600"
                    style={{ width: `${reflectance.perfusionScore}%` }}
                  ></div>
                </div>
              </div>

              <div className="pt-3 border-t">
                <p className="text-xs text-muted-foreground">
                  ℹ️ Analyzes RGB spectral patterns to estimate blood perfusion and tissue oxygenation.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Micro-Pulse Analysis */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-yellow-500" />
              Micro-Pulse Frequency Shift Analysis
            </CardTitle>
            <CardDescription>Heart rate variability and autonomic nervous system assessment</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4 mb-6">
              <div className="bg-cyan-50 dark:bg-cyan-950 p-4 rounded-lg">
                <p className="text-xs text-muted-foreground mb-1">Heart Rate</p>
                <p className="text-3xl font-bold text-cyan-600">{Math.round(microPulse.instantaneousFrequency)}</p>
                <p className="text-xs text-muted-foreground mt-1">bpm</p>
              </div>

              <div className="bg-green-50 dark:bg-green-950 p-4 rounded-lg">
                <p className="text-xs text-muted-foreground mb-1">HRV (Variability)</p>
                <p className="text-3xl font-bold text-green-600">
                  {(microPulse.frequencyVariability * 1000).toFixed(0)}
                </p>
                <p className="text-xs text-muted-foreground mt-1">milliseconds</p>
              </div>

              <div className="bg-indigo-50 dark:bg-indigo-950 p-4 rounded-lg">
                <p className="text-xs text-muted-foreground mb-1">LF/HF Ratio</p>
                <p className="text-3xl font-bold text-indigo-600">{microPulse.lfHfRatio.toFixed(2)}</p>
                <p className="text-xs text-muted-foreground mt-1">Autonomic balance</p>
              </div>

              <div className="bg-pink-50 dark:bg-pink-950 p-4 rounded-lg">
                <p className="text-xs text-muted-foreground mb-1">Sys/Dia Ratio</p>
                <p className="text-3xl font-bold text-pink-600">{microPulse.systolicDiastolicRatio.toFixed(2)}</p>
                <p className="text-xs text-muted-foreground mt-1">Vascular elasticity</p>
              </div>
            </div>

            <div className="bg-blue-50 dark:bg-blue-950 p-4 rounded-lg">
              <p className="text-sm font-medium mb-2 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-600" />
                Analysis Quality
              </p>
              <div className="space-y-1 text-sm">
                <p className="text-muted-foreground">✓ Sufficient PPG signal quality</p>
                <p className="text-muted-foreground">✓ Micro-pulse frequencies detected</p>
                <p className="text-muted-foreground">✓ Autonomic tone assessment complete</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Clinical Insights */}
        <Card>
          <CardHeader>
            <CardTitle>Clinical Insights & Recommendations</CardTitle>
            <CardDescription>Based on multimodal biomedical fusion analysis</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {scan.immunoScore >= 70 && (
                <div className="flex gap-3 p-3 bg-green-50 dark:bg-green-950 rounded-lg border border-green-200 dark:border-green-800">
                  <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-green-900 dark:text-green-100">Strong immune indicators detected</p>
                    <p className="text-sm text-green-800 dark:text-green-200">Thermal stability and good perfusion suggest healthy immune function. Continue regular monitoring.</p>
                  </div>
                </div>
              )}

              {scan.immunoScore >= 50 && scan.immunoScore < 70 && (
                <div className="flex gap-3 p-3 bg-yellow-50 dark:bg-yellow-950 rounded-lg border border-yellow-200 dark:border-yellow-800">
                  <AlertTriangle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-yellow-900 dark:text-yellow-100">Moderate immune compromise detected</p>
                    <p className="text-sm text-yellow-800 dark:text-yellow-200">HRV and perfusion patterns suggest elevated stress on immune system. Recommend lifestyle optimization and follow-up scan in 1-2 weeks.</p>
                  </div>
                </div>
              )}

              {scan.immunoScore < 50 && (
                <div className="flex gap-3 p-3 bg-red-50 dark:bg-red-950 rounded-lg border border-red-200 dark:border-red-800">
                  <TrendingDown className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="font-medium text-red-900 dark:text-red-100">Significant immune weakness indicators</p>
                    <p className="text-sm text-red-800 dark:text-red-200">Reduced perfusion and elevated thermal variation suggest immune system stress. Strongly recommend consultation with healthcare provider and confirmatory clinical testing.</p>
                  </div>
                </div>
              )}

              <div className="mt-4 p-3 bg-muted rounded-lg">
                <p className="text-sm font-medium mb-2">Next Steps:</p>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Schedule follow-up scan in 7 days</li>
                  <li>• Maintain consistent sleep schedule</li>
                  <li>• Monitor for fever or respiratory symptoms</li>
                  <li>• Consider clinical lab testing (CBC, CD4 count)</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
