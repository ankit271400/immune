import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, Calendar, Thermometer, TrendingUp, Clock, Trash2 } from "lucide-react";
import { formatDistanceToNow, format } from "date-fns";
import type { Scan } from "@shared/schema";

const MirrorHistoryPage = () => {
  const { data: scans = [], isLoading } = useQuery<Scan[]>({
    queryKey: ["/api/scans"],
  });

  const getRiskColor = (level: string) => {
    if (level === "low") return "bg-green-500/10 text-green-700 dark:text-green-400 border-green-200 dark:border-green-900";
    if (level === "moderate") return "bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-200 dark:border-amber-900";
    return "bg-red-500/10 text-red-700 dark:text-red-400 border-red-200 dark:border-red-900";
  };

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <Clock className="w-6 h-6 text-primary" />
            </div>
            <h1 className="text-4xl font-bold">Scan History</h1>
          </div>
          <p className="text-lg text-muted-foreground">
            All immune scans (smartphone & mirror) from the last 6 months. Older scans are automatically removed.
          </p>
        </div>

        {/* Stats */}
        {scans.length > 0 && (
          <div className="grid md:grid-cols-4 gap-4 mb-8">
            <Card className="hover-elevate">
              <CardContent className="pt-6">
                <p className="text-sm font-medium text-muted-foreground mb-1">Total Scans</p>
                <p className="text-3xl font-bold">{scans.length}</p>
              </CardContent>
            </Card>
            <Card className="hover-elevate">
              <CardContent className="pt-6">
                <p className="text-sm font-medium text-muted-foreground mb-1">Average Score</p>
                <p className="text-3xl font-bold">
                  {Math.round(scans.reduce((sum, s) => sum + s.immunoScore, 0) / scans.length)}
                </p>
              </CardContent>
            </Card>
            <Card className="hover-elevate">
              <CardContent className="pt-6">
                <p className="text-sm font-medium text-muted-foreground mb-1">Latest Scan</p>
                <p className="text-sm font-semibold">
                  {scans.length > 0 ? format(new Date(scans[0].timestamp), "MMM dd, yyyy") : "N/A"}
                </p>
              </CardContent>
            </Card>
            <Card className="hover-elevate">
              <CardContent className="pt-6">
                <p className="text-sm font-medium text-muted-foreground mb-1">Retention</p>
                <p className="text-sm font-semibold">Up to 6 months</p>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Scans List */}
        {isLoading ? (
          <div className="text-center py-12">
            <Activity className="w-12 h-12 text-muted-foreground mx-auto mb-4 animate-spin" />
            <p className="text-muted-foreground">Loading scan history...</p>
          </div>
        ) : scans.length === 0 ? (
          <Card className="text-center py-12">
            <CardContent>
              <Clock className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
              <p className="text-muted-foreground mb-4">No scans yet</p>
              <p className="text-sm text-muted-foreground">
                Complete a scan to see your immune health history
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-4">
            {scans.map((scan) => (
              <Card key={scan.id} className="hover-elevate overflow-hidden">
                <CardContent className="p-0">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 p-6">
                    {/* Left: Score and Date */}
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-16 rounded-lg bg-gradient-to-br from-primary/10 to-chart-2/10 flex items-center justify-center flex-shrink-0">
                        <div className="text-center">
                          <p className="text-2xl font-bold text-primary">{scan.immunoScore}</p>
                        </div>
                      </div>
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <Calendar className="w-4 h-4 text-muted-foreground" />
                          <p className="text-sm text-muted-foreground">
                            {format(new Date(scan.timestamp), "PPp")}
                          </p>
                        </div>
                        <p className="text-xs text-muted-foreground">{scan.analysisNotes || "Immune health scan"}</p>
                      </div>
                    </div>

                    {/* Middle: Metrics */}
                    <div className="grid grid-cols-3 gap-4 md:w-auto">
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">HRV</p>
                        <p className="font-semibold">{(scan.heartRateVariability || 0).toFixed(0)} ms</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">Perfusion</p>
                        <p className="font-semibold">{(scan.perfusionIndex || 0).toFixed(1)}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground mb-1">Microvascular</p>
                        <p className="font-semibold">{(scan.microVascularHealth || 0).toFixed(0)}%</p>
                      </div>
                    </div>

                    {/* Right: Risk Level */}
                    <div className="flex items-center gap-3">
                      <Badge className={`${getRiskColor(scan.riskLevel)} border`}>
                        {scan.riskLevel.charAt(0).toUpperCase() + scan.riskLevel.slice(1)}
                      </Badge>
                    </div>
                  </div>

                  {/* Expanded Metrics */}
                  <div className="grid md:grid-cols-4 gap-4 px-6 pb-6 bg-muted/30 rounded-b-lg">
                    <div>
                      <p className="text-xs font-medium text-muted-foreground mb-1">Capillary Refill</p>
                      <div className="flex items-center gap-1">
                        <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-red-500"
                            style={{ width: `${Math.min((scan.capillaryRefillTime || 0) / 3 * 100, 100)}%` }}
                          />
                        </div>
                        <span className="text-xs font-semibold">{(scan.capillaryRefillTime || 0).toFixed(1)}s</span>
                      </div>
                    </div>
                    <div>
                      <p className="text-xs font-medium text-muted-foreground mb-1">Thermal Sig</p>
                      <div className="flex items-center gap-1">
                        <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-amber-700"
                            style={{ width: `${Math.min((scan.thermalSignature || 0) / 100 * 100, 100)}%` }}
                          />
                        </div>
                        <span className="text-xs font-semibold">{(scan.thermalSignature || 0).toFixed(0)}</span>
                      </div>
                    </div>
                    <div>
                      <p className="text-xs font-medium text-muted-foreground mb-1">Perfusion</p>
                      <div className="flex items-center gap-1">
                        <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-blue-500"
                            style={{ width: `${Math.min((scan.perfusionIndex || 0) / 100 * 100, 100)}%` }}
                          />
                        </div>
                        <span className="text-xs font-semibold">{(scan.perfusionIndex || 0).toFixed(1)}</span>
                      </div>
                    </div>
                    <div>
                      <p className="text-xs font-medium text-muted-foreground mb-1">Microvascular</p>
                      <div className="flex items-center gap-1">
                        <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-green-500"
                            style={{ width: `${Math.min((scan.microVascularHealth || 0) / 100 * 100, 100)}%` }}
                          />
                        </div>
                        <span className="text-xs font-semibold">{(scan.microVascularHealth || 0).toFixed(0)}%</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Info Box */}
        <div className="mt-8 p-4 bg-primary/5 rounded-lg border border-primary/20">
          <p className="text-sm text-muted-foreground">
            <strong>Auto-Cleanup Policy:</strong> Mirror scan records are automatically retained for 6 months from the scan date. Scans older than 6 months are automatically deleted to maintain database efficiency and comply with data retention policies.
          </p>
        </div>
      </div>
    </div>
  );
};

export default MirrorHistoryPage;
