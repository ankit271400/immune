import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import { ThemeToggle } from "@/components/theme-toggle";
import Home from "@/pages/home";
import ScanPage from "@/pages/scan";
import ResultsPage from "@/pages/results";
import HistoryPage from "@/pages/history";
import ImmunoGraphPage from "@/pages/immunograph";
import PerformancePage from "@/pages/performance";
import FeaturesPage from "@/pages/features";
import AnalysisPage from "@/pages/analysis";
import BioSignalDashboard from "@/pages/bio-signal-dashboard";
import NotFound from "@/pages/not-found";
import { Activity, Zap, Sparkles, Microscope } from "lucide-react";
import { Link, useLocation } from "wouter";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/scan" component={ScanPage} />
      <Route path="/results/:score" component={ResultsPage} />
      <Route path="/history" component={HistoryPage} />
      <Route path="/immunograph" component={ImmunoGraphPage} />
      <Route path="/performance" component={PerformancePage} />
      <Route path="/features" component={FeaturesPage} />
      <Route path="/bio-signals" component={BioSignalDashboard} />
      <Route path="/analysis/:id" component={AnalysisPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AppHeader() {
  const [location] = useLocation();
  
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between max-w-7xl">
        <Link href="/">
          <div className="flex items-center gap-3 cursor-pointer hover-elevate active-elevate-2 px-3 py-2 rounded-lg -ml-3" data-testid="link-home">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <Activity className="w-5 h-5 text-primary-foreground" />
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-lg leading-none">ImmunoAI</span>
              <span className="text-xs text-muted-foreground leading-none">Immune Health Screening</span>
            </div>
          </div>
        </Link>
        <div className="flex items-center gap-2">
          <Link href="/bio-signals">
            <div className={`flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer hover-elevate active-elevate-2 ${location === "/bio-signals" ? "bg-primary/10" : ""}`} data-testid="link-bio-signals">
              <Microscope className="w-4 h-4" />
              <span className="text-sm font-medium hidden sm:inline">BioSignals</span>
            </div>
          </Link>
          <Link href="/features">
            <div className={`flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer hover-elevate active-elevate-2 ${location === "/features" ? "bg-primary/10" : ""}`} data-testid="link-features">
              <Sparkles className="w-4 h-4" />
              <span className="text-sm font-medium hidden sm:inline">Features</span>
            </div>
          </Link>
          <Link href="/performance">
            <div className={`flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer hover-elevate active-elevate-2 ${location === "/performance" ? "bg-primary/10" : ""}`} data-testid="link-performance">
              <Zap className="w-4 h-4" />
              <span className="text-sm font-medium hidden sm:inline">Performance</span>
            </div>
          </Link>
          <ThemeToggle />
        </div>
      </div>
    </header>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          <div className="min-h-screen flex flex-col">
            <AppHeader />
            <main className="flex-1">
              <Router />
            </main>
          </div>
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
