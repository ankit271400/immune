import { useState } from "react";
import { useLocation, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
  Area,
  ComposedChart,
} from "recharts";
import {
  ArrowLeft,
  TrendingUp,
  TrendingDown,
  Activity,
  Shield,
  Zap,
  AlertCircle,
  CheckCircle2,
  Battery,
  Heart,
} from "lucide-react";
import type { ImmunoGraph, Scan } from "@shared/schema";

export default function ImmunoGraphPage() {
  const [, setLocation] = useLocation();

  const { data: immunoGraph, isLoading: graphLoading } = useQuery<ImmunoGraph>({
    queryKey: ["/api/immunograph"],
  });

  const { data: scans } = useQuery<Scan[]>({
    queryKey: ["/api/scans"],
  });

  if (graphLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Activity className="w-12 h-12 animate-spin mx-auto mb-4 text-primary" />
          <p className="text-muted-foreground">Loading ImmunoGraph™...</p>
        </div>
      </div>
    );
  }

  if (!immunoGraph) {
    return (
      <div className="min-h-screen bg-background">
        <div className="container mx-auto px-4 py-8 max-w-5xl">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="mb-8 gap-2 hover-elevate active-elevate-2"
            data-testid="button-back"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Button>

          <Alert>
            <AlertCircle className="w-4 h-4" />
            <AlertDescription>
              No ImmunoGraph™ data available. Complete at least one scan to generate your personalized immune timeline.
            </AlertDescription>
          </Alert>

          <div className="mt-8">
            <Link href="/scan">
              <Button size="lg" className="w-full gap-2" data-testid="button-start-scan">
                <Activity className="w-5 h-5" />
                Start Your First Scan
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const getTrendIcon = () => {
    if (!immunoGraph.declineRate) return <Activity className="w-4 h-4" />;
    if (immunoGraph.declineRate > 0) return <TrendingUp className="w-4 h-4 text-green-500" />;
    if (immunoGraph.declineRate < 0) return <TrendingDown className="w-4 h-4 text-red-500" />;
    return <Activity className="w-4 h-4 text-amber-500" />;
  };

  const getTrendText = () => {
    if (!immunoGraph.declineRate) return "Stable";
    if (immunoGraph.declineRate > 0) return "Improving";
    if (immunoGraph.declineRate < 0) return "Declining";
    return "Stable";
  };

  const chartData = immunoGraph.predictedTrajectory?.map(point => ({
    date: new Date(point.date).toLocaleDateString("en-US", { month: "short", day: "numeric" }),
    score: point.predictedScore,
    confidence: point.confidence * 100,
    isActual: point.isActual,
  })) || [];

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="gap-2 hover-elevate active-elevate-2"
            data-testid="button-back"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Button>
        </div>

        <div className="mb-12">
          <h1 className="text-4xl font-bold mb-3 flex items-center gap-3">
            <Shield className="w-10 h-10 text-primary" />
            ImmunoGraph™
          </h1>
          <p className="text-muted-foreground text-lg">
            Your personalized immune trajectory model using Temporal Transformers & Bayesian updating
          </p>
        </div>

        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card className="hover-elevate">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2 text-muted-foreground">
                <Battery className="w-4 h-4" />
                Immune Reserve Power
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold" data-testid="text-reserve-power">
                {immunoGraph.immuneReservePower?.toFixed(1) || "N/A"}
              </div>
              <Progress value={immunoGraph.immuneReservePower || 0} className="h-2 mt-3" />
            </CardContent>
          </Card>

          <Card className="hover-elevate">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2 text-muted-foreground">
                {getTrendIcon()}
                Trend Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="text-trend">
                {getTrendText()}
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                {immunoGraph.declineRate !== null && immunoGraph.declineRate !== undefined
                  ? `${immunoGraph.declineRate > 0 ? "+" : ""}${immunoGraph.declineRate.toFixed(1)}% per week`
                  : "Calculating..."}
              </p>
            </CardContent>
          </Card>

          <Card className="hover-elevate">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2 text-muted-foreground">
                <Heart className="w-4 h-4" />
                Recovery Probability
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold" data-testid="text-recovery">
                {((immunoGraph.recoveryProbability || 0) * 100).toFixed(0)}%
              </div>
              <Progress value={(immunoGraph.recoveryProbability || 0) * 100} className="h-2 mt-3" />
            </CardContent>
          </Card>

          <Card className="hover-elevate">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2 text-muted-foreground">
                <Zap className="w-4 h-4" />
                Confidence Score
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold" data-testid="text-confidence">
                {((immunoGraph.confidenceScore || 0) * 100).toFixed(0)}%
              </div>
              <p className="text-sm text-muted-foreground mt-1">
                {immunoGraph.confidenceScore && immunoGraph.confidenceScore > 0.7 ? "High" : "Building..."}
              </p>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-xl">Immune Trajectory Timeline</CardTitle>
            <CardDescription>
              Historical data (solid line) and AI-predicted future trajectory (dashed line)
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-96">
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={chartData}>
                  <defs>
                    <linearGradient id="scoreGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis
                    dataKey="date"
                    className="text-xs"
                    tick={{ fill: "hsl(var(--muted-foreground))" }}
                  />
                  <YAxis
                    domain={[0, 100]}
                    className="text-xs"
                    tick={{ fill: "hsl(var(--muted-foreground))" }}
                    label={{ value: "ImmunoScore", angle: -90, position: "insideLeft" }}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--popover))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "0.5rem",
                    }}
                  />
                  <Legend />
                  <ReferenceLine y={80} stroke="hsl(var(--chart-2))" strokeDasharray="3 3" label="Optimal" />
                  <ReferenceLine y={50} stroke="hsl(var(--chart-5))" strokeDasharray="3 3" label="Alert Threshold" />
                  <Area
                    type="monotone"
                    dataKey="score"
                    stroke="hsl(var(--primary))"
                    fill="url(#scoreGradient)"
                    fillOpacity={0.3}
                  />
                  <Line
                    type="monotone"
                    dataKey="score"
                    stroke="hsl(var(--primary))"
                    strokeWidth={3}
                    dot={{ r: 5, fill: "hsl(var(--primary))" }}
                    activeDot={{ r: 7 }}
                    name="ImmunoScore"
                  />
                </ComposedChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Bayesian Update History</CardTitle>
              <CardDescription>AI model refinement over time</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Total Scans</span>
                  <Badge variant="outline" className="font-mono">
                    {scans?.length || 0}
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Model Confidence</span>
                  <Badge variant="outline" className="font-mono">
                    {((immunoGraph.confidenceScore || 0) * 100).toFixed(1)}%
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Last Updated</span>
                  <Badge variant="outline" className="font-mono">
                    {new Date(immunoGraph.updatedAt).toLocaleDateString()}
                  </Badge>
                </div>
                <div className="pt-3 border-t">
                  <p className="text-sm text-muted-foreground">
                    {immunoGraph.confidenceScore && immunoGraph.confidenceScore > 0.7
                      ? "Model has high confidence. Predictions are reliable."
                      : "Collecting more data to improve prediction accuracy."}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">AI Insights</CardTitle>
              <CardDescription>Temporal pattern analysis</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {immunoGraph.declineRate && immunoGraph.declineRate < -2 && (
                  <Alert className="bg-red-50 dark:bg-red-950/30 border-red-200 dark:border-red-900">
                    <AlertCircle className="w-4 h-4 text-red-600 dark:text-red-400" />
                    <AlertDescription className="text-sm">
                      <strong>Declining Trend Detected:</strong> Your immune score is declining at {Math.abs(immunoGraph.declineRate).toFixed(1)}% per week. Consider consulting a healthcare provider.
                    </AlertDescription>
                  </Alert>
                )}

                {immunoGraph.declineRate && immunoGraph.declineRate > 2 && (
                  <Alert className="bg-green-50 dark:bg-green-950/30 border-green-200 dark:border-green-900">
                    <CheckCircle2 className="w-4 h-4 text-green-600 dark:text-green-400" />
                    <AlertDescription className="text-sm">
                      <strong>Improving Trend:</strong> Your immune health is improving at {immunoGraph.declineRate.toFixed(1)}% per week. Keep up the healthy habits!
                    </AlertDescription>
                  </Alert>
                )}

                {immunoGraph.recoveryProbability && immunoGraph.recoveryProbability < 0.4 && (
                  <Alert className="bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-900">
                    <AlertCircle className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                    <AlertDescription className="text-sm">
                      Recovery probability is {(immunoGraph.recoveryProbability * 100).toFixed(0)}%. Focus on stress reduction, sleep, and nutrition.
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="mt-8 flex flex-col sm:flex-row gap-4">
          <Link href="/scan" className="flex-1">
            <Button size="lg" className="w-full gap-2" data-testid="button-new-scan">
              <Activity className="w-5 h-5" />
              New Scan
            </Button>
          </Link>
          <Link href="/history" className="flex-1">
            <Button size="lg" variant="outline" className="w-full gap-2 hover-elevate active-elevate-2" data-testid="button-history">
              <Shield className="w-5 h-5" />
              View History
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
