import { useEffect, useState } from "react";
import { useRoute, useLocation, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Activity,
  Heart,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  Download,
  Share2,
  ArrowLeft,
  Info,
  BookOpen,
  Thermometer,
  Droplets,
  Shield,
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { Scan } from "@shared/schema";

export default function ResultsPage() {
  const [, params] = useRoute("/results/:score");
  const [, setLocation] = useLocation();
  const [animatedScore, setAnimatedScore] = useState(0);
  const [showEducation, setShowEducation] = useState(false);
  const targetScore = params?.score ? parseInt(params.score) : 0;

  const { data: scans } = useQuery<Scan[]>({
    queryKey: ["/api/scans"],
  });

  const latestScan = scans?.[0];

  useEffect(() => {
    if (targetScore > 0) {
      const duration = 1500;
      const steps = 60;
      const increment = targetScore / steps;
      const stepDuration = duration / steps;
      
      let current = 0;
      const timer = setInterval(() => {
        current += increment;
        if (current >= targetScore) {
          setAnimatedScore(targetScore);
          clearInterval(timer);
        } else {
          setAnimatedScore(Math.floor(current));
        }
      }, stepDuration);
      
      return () => clearInterval(timer);
    }
  }, [targetScore]);

  const getRiskLevel = (score: number): { level: string; color: string; bgColor: string; icon: React.ReactNode } => {
    if (score >= 80) {
      return {
        level: "Strong Immune Health",
        color: "text-green-600 dark:text-green-400",
        bgColor: "bg-green-50 dark:bg-green-950/30 border-green-200 dark:border-green-900",
        icon: <CheckCircle2 className="w-5 h-5" />,
      };
    } else if (score >= 50) {
      return {
        level: "Moderate - Monitor Closely",
        color: "text-amber-600 dark:text-amber-400",
        bgColor: "bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-900",
        icon: <Info className="w-5 h-5" />,
      };
    } else {
      return {
        level: "Attention Needed",
        color: "text-red-600 dark:text-red-400",
        bgColor: "bg-red-50 dark:bg-red-950/30 border-red-200 dark:border-red-900",
        icon: <AlertTriangle className="w-5 h-5" />,
      };
    }
  };

  const riskInfo = getRiskLevel(animatedScore);

  const handleExport = () => {
    console.log("Exporting report...");
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: "My ImmunoScore",
        text: `I just checked my immune health with ImmunoAI. My score: ${targetScore}`,
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-5xl">
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => setLocation("/")}
            className="gap-2 hover-elevate active-elevate-2"
            data-testid="button-back"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Button>
        </div>

        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold mb-3">Your ImmunoScore™</h1>
          <p className="text-muted-foreground text-lg">
            Comprehensive immune health analysis complete
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle>ImmunoScore™</CardTitle>
              <CardDescription>Your immune system integrity rating (0-100)</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center justify-center py-8">
                <div className="relative w-64 h-64 flex items-center justify-center">
                  <svg className="w-full h-full -rotate-90">
                    <circle
                      cx="128"
                      cy="128"
                      r="120"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="12"
                      className="text-muted/20"
                    />
                    <circle
                      cx="128"
                      cy="128"
                      r="120"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="12"
                      strokeLinecap="round"
                      className={animatedScore >= 80 ? "text-green-500" : animatedScore >= 50 ? "text-amber-500" : "text-red-500"}
                      strokeDasharray={`${(animatedScore / 100) * 754} 754`}
                      style={{ transition: "stroke-dasharray 0.3s ease" }}
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center flex-col">
                    <div className="text-6xl font-bold" data-testid="text-immunoscore">
                      {animatedScore}
                    </div>
                    <div className="text-sm text-muted-foreground font-medium mt-2">/ 100</div>
                  </div>
                </div>
                
                <Badge
                  className={`mt-6 px-4 py-2 gap-2 ${riskInfo.color}`}
                  variant="outline"
                  data-testid="badge-risk-level"
                >
                  {riskInfo.icon}
                  {riskInfo.level}
                </Badge>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-4">
            <Card className="hover-elevate">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Heart className="w-4 h-4 text-primary" />
                  Pulse Rate
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{latestScan?.metrics?.pulseRate || 72}</div>
                <div className="text-sm text-muted-foreground">bpm</div>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <Activity className="w-4 h-4 text-chart-2" />
                  HRV Index
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{latestScan?.heartRateVariability?.toFixed(1) || "45.2"}</div>
                <div className="text-sm text-muted-foreground">ms</div>
              </CardContent>
            </Card>

            <Card className="hover-elevate">
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-chart-3" />
                  Perfusion
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{latestScan?.perfusionIndex?.toFixed(1) || "8.4"}</div>
                <div className="text-sm text-muted-foreground">index</div>
              </CardContent>
            </Card>
          </div>
        </div>

        {animatedScore < 80 && (
          <Alert className={`mb-8 ${riskInfo.bgColor}`}>
            {riskInfo.icon}
            <AlertTitle className="text-base font-semibold">Health Recommendations</AlertTitle>
            <AlertDescription className="mt-2">
              {animatedScore >= 50 ? (
                <div className="space-y-1 text-sm">
                  <p>• Maintain regular sleep schedule (7-9 hours)</p>
                  <p>• Consider increasing vitamin D and zinc intake</p>
                  <p>• Schedule follow-up scan in 2 weeks</p>
                </div>
              ) : (
                <div className="space-y-1 text-sm">
                  <p>• <strong>Consult healthcare provider for comprehensive evaluation</strong></p>
                  <p>• Consider complete blood count (CBC) and immune panel tests</p>
                  <p>• Immediate lifestyle adjustments recommended</p>
                </div>
              )}
            </AlertDescription>
          </Alert>
        )}

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Detailed Metrics</CardTitle>
              <CardDescription>Individual health indicators</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="flex justify-between mb-2 text-sm">
                  <span className="text-muted-foreground">Microvascular Health</span>
                  <span className="font-medium">{latestScan?.microVascularHealth?.toFixed(0) || "82"}%</span>
                </div>
                <Progress value={latestScan?.microVascularHealth || 82} className="h-2" />
              </div>

              <div>
                <div className="flex justify-between mb-2 text-sm">
                  <span className="text-muted-foreground">Capillary Refill</span>
                  <span className="font-medium">{latestScan?.capillaryRefillTime?.toFixed(1) || "1.8"}s</span>
                </div>
                <Progress value={100 - (latestScan?.capillaryRefillTime || 1.8) * 30} className="h-2" />
              </div>

              <div>
                <div className="flex justify-between mb-2 text-sm">
                  <span className="text-muted-foreground">Oxygen Saturation</span>
                  <span className="font-medium">{latestScan?.metrics?.oxygenSaturation || 98}%</span>
                </div>
                <Progress value={latestScan?.metrics?.oxygenSaturation || 98} className="h-2" />
              </div>

              <div>
                <div className="flex justify-between mb-2 text-sm">
                  <span className="text-muted-foreground">Immune Response Index</span>
                  <span className="font-medium">{latestScan?.metrics?.immuneResponseIndex || 76}%</span>
                </div>
                <Progress value={latestScan?.metrics?.immuneResponseIndex || 76} className="h-2" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">AI Analysis Notes</CardTitle>
              <CardDescription>Key observations from scan</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-sm space-y-3">
                <p className="text-muted-foreground">
                  {latestScan?.analysisNotes || 
                    "Analysis indicates normal microvascular function with slight variability in heart rate patterns. Perfusion index within healthy range. No immediate concerns detected in thermal signature or capillary refill patterns."}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <Dialog open={showEducation} onOpenChange={setShowEducation}>
            <DialogTrigger asChild>
              <Button
                size="lg"
                variant="outline"
                className="flex-1 gap-2 hover-elevate active-elevate-2"
                data-testid="button-learn-metrics"
              >
                <BookOpen className="w-5 h-5" />
                Learn About Metrics
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Understanding Your ImmunoScore™</DialogTitle>
                <DialogDescription>
                  Learn what each health metric means and how it contributes to your overall immune health assessment
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-6 mt-4">
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Shield className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">ImmunoScore™ (0-100)</h3>
                      <p className="text-sm text-muted-foreground">Overall immune system integrity</p>
                    </div>
                  </div>
                  <p className="text-sm">
                    Your ImmunoScore is a comprehensive rating that combines multiple physiological markers to assess your immune system's overall health. 
                    Scores above 80 indicate strong immune function, 50-79 suggest moderate health requiring monitoring, and below 50 indicates the need for medical attention.
                  </p>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-chart-2/20 flex items-center justify-center">
                      <Activity className="w-5 h-5 text-chart-2" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Heart Rate Variability (HRV)</h3>
                      <p className="text-sm text-muted-foreground">Autonomic nervous system balance</p>
                    </div>
                  </div>
                  <p className="text-sm">
                    HRV measures the variation in time between heartbeats. Higher HRV (typically 30-60ms) indicates better autonomic nervous system function 
                    and stress resilience. Low HRV can indicate fatigue, stress, or immune system strain.
                  </p>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-chart-3/20 flex items-center justify-center">
                      <Droplets className="w-5 h-5 text-chart-3" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Capillary Refill Time</h3>
                      <p className="text-sm text-muted-foreground">Microvascular perfusion</p>
                    </div>
                  </div>
                  <p className="text-sm">
                    Measures how quickly blood returns to capillaries after pressure. Normal is 1.0-2.0 seconds. Prolonged refill time can indicate 
                    circulation issues or dehydration, both of which can impact immune function.
                  </p>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <TrendingUp className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Perfusion Index</h3>
                      <p className="text-sm text-muted-foreground">Blood flow efficiency</p>
                    </div>
                  </div>
                  <p className="text-sm">
                    Indicates the strength of blood flow to peripheral tissues. Values between 5-12 are normal. Low perfusion can indicate poor 
                    circulation, which affects the delivery of immune cells throughout the body.
                  </p>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-red-50 dark:bg-red-950/30 flex items-center justify-center">
                      <Thermometer className="w-5 h-5 text-red-500" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Thermal Signature</h3>
                      <p className="text-sm text-muted-foreground">Inflammatory markers</p>
                    </div>
                  </div>
                  <p className="text-sm">
                    Analyzes temperature patterns that correlate with inflammation. Normal body temperature (95-99°F) indicates balanced immune response. 
                    Variations can suggest active immune activity or fever.
                  </p>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-green-50 dark:bg-green-950/30 flex items-center justify-center">
                      <Heart className="w-5 h-5 text-green-500" />
                    </div>
                    <div>
                      <h3 className="font-semibold">Microvascular Health</h3>
                      <p className="text-sm text-muted-foreground">Capillary function</p>
                    </div>
                  </div>
                  <p className="text-sm">
                    Assesses the health and function of small blood vessels. Strong microvascular health (60-95%) ensures efficient nutrient delivery 
                    and waste removal, critical for immune cell function and tissue repair.
                  </p>
                </div>
              </div>
            </DialogContent>
          </Dialog>
          
          <Button
            size="lg"
            variant="outline"
            className="flex-1 gap-2 hover-elevate active-elevate-2"
            onClick={handleExport}
            data-testid="button-export"
          >
            <Download className="w-5 h-5" />
            Export Report
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="flex-1 gap-2 hover-elevate active-elevate-2"
            onClick={handleShare}
            data-testid="button-share"
          >
            <Share2 className="w-5 h-5" />
            Share Results
          </Button>
          <Link href="/scan" className="flex-1">
            <Button size="lg" className="w-full gap-2" data-testid="button-new-scan">
              <Activity className="w-5 h-5" />
              New Scan
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
