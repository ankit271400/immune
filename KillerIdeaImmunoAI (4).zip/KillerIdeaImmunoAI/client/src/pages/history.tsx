import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, TrendingUp, TrendingDown, Activity, Calendar, Microscope } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import type { Scan } from "@shared/schema";
import { format } from "date-fns";

export default function HistoryPage() {
  const { data: scans, isLoading } = useQuery<Scan[]>({
    queryKey: ["/api/scans"],
  });

  const getRiskBadgeColor = (score: number) => {
    if (score >= 80) return "bg-green-100 text-green-800 dark:bg-green-950 dark:text-green-300";
    if (score >= 50) return "bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300";
    return "bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300";
  };

  const getTrendIndicator = (current: number, previous: number) => {
    if (current > previous) {
      return { icon: <TrendingUp className="w-4 h-4" />, color: "text-green-600 dark:text-green-400", text: `+${current - previous}` };
    } else if (current < previous) {
      return { icon: <TrendingDown className="w-4 h-4" />, color: "text-red-600 dark:text-red-400", text: `${current - previous}` };
    }
    return { icon: null, color: "text-muted-foreground", text: "No change" };
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8 max-w-5xl">
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => window.history.back()}
            className="gap-2 hover-elevate active-elevate-2"
            data-testid="button-back"
          >
            <ArrowLeft className="w-4 h-4" />
            Back
          </Button>
        </div>

        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold mb-2">Scan History</h1>
            <p className="text-muted-foreground text-lg">
              Track your immune health over time
            </p>
          </div>
          <Link href="/scan">
            <Button size="lg" className="gap-2" data-testid="button-new-scan">
              <Activity className="w-5 h-5" />
              New Scan
            </Button>
          </Link>
        </div>

        {isLoading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader>
                  <div className="h-6 bg-muted rounded w-1/3"></div>
                  <div className="h-4 bg-muted rounded w-1/4 mt-2"></div>
                </CardHeader>
                <CardContent>
                  <div className="h-24 bg-muted rounded"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : scans && scans.length > 0 ? (
          <div className="space-y-6">
            {scans.map((scan, index) => {
              const previousScan = scans[index + 1];
              const trend = previousScan ? getTrendIndicator(scan.immunoScore, previousScan.immunoScore) : null;

              return (
                <Card key={scan.id} className="hover-elevate" data-testid={`card-scan-${scan.id}`}>
                  <CardHeader>
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <CardTitle className="text-xl">ImmunoScore: {scan.immunoScore}</CardTitle>
                          <Badge className={getRiskBadgeColor(scan.immunoScore)} data-testid={`badge-risk-${scan.id}`}>
                            {scan.riskLevel}
                          </Badge>
                          {trend && trend.icon && (
                            <div className={`flex items-center gap-1 ${trend.color}`}>
                              {trend.icon}
                              <span className="text-sm font-medium">{trend.text}</span>
                            </div>
                          )}
                        </div>
                        <CardDescription className="flex items-center gap-2">
                          <Calendar className="w-4 h-4" />
                          {format(new Date(scan.timestamp), "PPpp")}
                        </CardDescription>
                      </div>
                      <Link href={`/results/${scan.immunoScore}`}>
                        <Button variant="outline" className="hover-elevate active-elevate-2" data-testid={`button-view-${scan.id}`}>
                          View Details
                        </Button>
                      </Link>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                      <div>
                        <div className="text-sm text-muted-foreground mb-1">HRV</div>
                        <div className="text-lg font-semibold">{scan.heartRateVariability?.toFixed(1) || "N/A"} ms</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground mb-1">Perfusion</div>
                        <div className="text-lg font-semibold">{scan.perfusionIndex?.toFixed(1) || "N/A"}</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground mb-1">Capillary</div>
                        <div className="text-lg font-semibold">{scan.capillaryRefillTime?.toFixed(1) || "N/A"}s</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground mb-1">Pulse</div>
                        <div className="text-lg font-semibold">{scan.metrics?.pulseRate || "N/A"} bpm</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        ) : (
          <Card className="text-center py-16">
            <CardContent>
              <Activity className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-xl font-semibold mb-2">No Scans Yet</h3>
              <p className="text-muted-foreground mb-6">
                Start your first immune health scan to begin tracking your wellness
              </p>
              <Link href="/scan">
                <Button size="lg" className="gap-2" data-testid="button-first-scan">
                  <Activity className="w-5 h-5" />
                  Start First Scan
                </Button>
              </Link>
            </CardContent>
          </Card>
        )}

        {scans && scans.length > 1 && (
          <Card className="mt-8 bg-primary/5">
            <CardHeader>
              <CardTitle className="text-lg">Trend Analysis</CardTitle>
              <CardDescription>Overall immune health progression</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid sm:grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary">{scans.length}</div>
                  <div className="text-sm text-muted-foreground mt-1">Total Scans</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold">
                    {Math.round(scans.reduce((sum, s) => sum + s.immunoScore, 0) / scans.length)}
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">Average Score</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-chart-2">
                    {Math.max(...scans.map(s => s.immunoScore))}
                  </div>
                  <div className="text-sm text-muted-foreground mt-1">Best Score</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
