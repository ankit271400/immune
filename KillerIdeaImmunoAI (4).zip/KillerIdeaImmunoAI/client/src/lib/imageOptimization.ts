/**
 * Image Optimization & Compression Module
 * Implements client-side image processing for faster uploads
 * Includes dynamic quality adjustment and progressive compression
 */

export interface CompressionOptions {
  maxWidth?: number;
  maxHeight?: number;
  quality?: number;
  format?: "jpeg" | "webp";
}

export interface CompressionResult {
  dataUrl: string;
  originalSize: number;
  compressedSize: number;
  compressionRatio: number;
  processingTimeMs: number;
}

/**
 * Compresses and optimizes an image for faster upload
 * Uses canvas-based compression with dynamic quality adjustment
 */
export async function compressImage(
  imageData: string,
  options: CompressionOptions = {}
): Promise<CompressionResult> {
  const startTime = performance.now();

  const {
    maxWidth = 640,
    maxHeight = 480,
    quality = 0.8,
    format = "jpeg",
  } = options;

  return new Promise((resolve, reject) => {
    const img = new Image();

    img.onload = () => {
      try {
        // Calculate new dimensions while maintaining aspect ratio
        let { width, height } = img;
        
        if (width > maxWidth) {
          height = (height * maxWidth) / width;
          width = maxWidth;
        }
        
        if (height > maxHeight) {
          width = (width * maxHeight) / height;
          height = maxHeight;
        }

        // Create canvas for compression
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");

        if (!ctx) {
          reject(new Error("Failed to get canvas context"));
          return;
        }

        // Draw and compress
        ctx.drawImage(img, 0, 0, width, height);
        const mimeType = format === "webp" ? "image/webp" : "image/jpeg";
        const compressedDataUrl = canvas.toDataURL(mimeType, quality);

        const originalSize = imageData.length;
        const compressedSize = compressedDataUrl.length;
        const processingTimeMs = performance.now() - startTime;

        resolve({
          dataUrl: compressedDataUrl,
          originalSize,
          compressedSize,
          compressionRatio: originalSize / compressedSize,
          processingTimeMs,
        });
      } catch (error) {
        reject(error);
      }
    };

    img.onerror = () => {
      reject(new Error("Failed to load image"));
    };

    img.src = imageData;
  });
}

/**
 * Dynamically adjusts compression quality based on device capability
 * Uses performance metrics to optimize for speed vs quality
 */
export function getDynamicCompressionOptions(): CompressionOptions {
  // Check device memory (if available)
  const deviceMemory = (navigator as any).deviceMemory || 4;
  
  // Check connection speed (if available)
  const connection = (navigator as any).connection;
  const effectiveType = connection?.effectiveType || "4g";

  // Adjust based on device capability
  if (deviceMemory >= 8 && effectiveType === "4g") {
    return {
      maxWidth: 800,
      maxHeight: 600,
      quality: 0.85,
      format: "webp",
    };
  } else if (deviceMemory >= 4 && (effectiveType === "4g" || effectiveType === "3g")) {
    return {
      maxWidth: 640,
      maxHeight: 480,
      quality: 0.8,
      format: "jpeg",
    };
  } else {
    // Budget devices or slow connections
    return {
      maxWidth: 480,
      maxHeight: 360,
      quality: 0.7,
      format: "jpeg",
    };
  }
}

/**
 * Batch compress multiple images with progressive loading
 */
export async function batchCompressImages(
  images: string[],
  options?: CompressionOptions,
  onProgress?: (current: number, total: number) => void
): Promise<CompressionResult[]> {
  const results: CompressionResult[] = [];
  
  for (let i = 0; i < images.length; i++) {
    const result = await compressImage(images[i], options);
    results.push(result);
    onProgress?.(i + 1, images.length);
  }
  
  return results;
}

/**
 * Performance monitoring utilities
 */
export interface PerformanceMetrics {
  scanStartTime: number;
  cameraReadyTime?: number;
  framesCapturedTime?: number;
  compressionTime?: number;
  uploadStartTime?: number;
  uploadCompleteTime?: number;
  aiProcessingTime?: number;
  totalTime?: number;
}

export class PerformanceMonitor {
  private metrics: PerformanceMetrics;

  constructor() {
    this.metrics = {
      scanStartTime: performance.now(),
    };
  }

  markCameraReady() {
    this.metrics.cameraReadyTime = performance.now() - this.metrics.scanStartTime;
  }

  markFramesCaptured() {
    this.metrics.framesCapturedTime = performance.now() - this.metrics.scanStartTime;
  }

  markCompressionComplete() {
    this.metrics.compressionTime = performance.now() - this.metrics.scanStartTime;
  }

  markUploadStart() {
    this.metrics.uploadStartTime = performance.now() - this.metrics.scanStartTime;
  }

  markUploadComplete() {
    this.metrics.uploadCompleteTime = performance.now() - this.metrics.scanStartTime;
  }

  markAIProcessingComplete() {
    this.metrics.aiProcessingTime = performance.now() - this.metrics.scanStartTime;
    this.metrics.totalTime = performance.now() - this.metrics.scanStartTime;
  }

  getMetrics(): PerformanceMetrics & { totalTime: number } {
    return {
      ...this.metrics,
      totalTime: this.metrics.totalTime || (performance.now() - this.metrics.scanStartTime),
    };
  }

  getSummary(): string {
    const m = this.getMetrics();
    return `
Scan Performance Metrics:
- Camera Ready: ${m.cameraReadyTime?.toFixed(0)}ms
- Frames Captured: ${m.framesCapturedTime?.toFixed(0)}ms
- Compression: ${m.compressionTime?.toFixed(0)}ms
- Upload: ${((m.uploadCompleteTime || 0) - (m.uploadStartTime || 0)).toFixed(0)}ms
- AI Processing: ${((m.aiProcessingTime || 0) - (m.uploadCompleteTime || 0)).toFixed(0)}ms
- Total Time: ${m.totalTime.toFixed(0)}ms
    `.trim();
  }
}
