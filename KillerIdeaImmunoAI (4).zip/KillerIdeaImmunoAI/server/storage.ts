import { scans, immunoGraphs, type Scan, type InsertScan, type ImmunoGraph, type InsertImmunoGraph } from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getScan(id: string): Promise<Scan | undefined>;
  getAllScans(): Promise<Scan[]>;
  createScan(scan: InsertScan): Promise<Scan>;
  getImmunoGraph(userId: string): Promise<ImmunoGraph | undefined>;
  createOrUpdateImmunoGraph(graph: InsertImmunoGraph): Promise<ImmunoGraph>;
}

export class DatabaseStorage implements IStorage {
  async getScan(id: string): Promise<Scan | undefined> {
    const [scan] = await db.select().from(scans).where(eq(scans.id, id));
    return scan || undefined;
  }

  async getAllScans(): Promise<Scan[]> {
    return await db.select().from(scans).orderBy(desc(scans.timestamp));
  }

  async createScan(insertScan: InsertScan): Promise<Scan> {
    const [scan] = await db
      .insert(scans)
      .values(insertScan)
      .returning();
    return scan;
  }

  async getImmunoGraph(userId: string = "default_user"): Promise<ImmunoGraph | undefined> {
    const [graph] = await db
      .select()
      .from(immunoGraphs)
      .where(eq(immunoGraphs.userId, userId))
      .orderBy(desc(immunoGraphs.updatedAt))
      .limit(1);
    return graph || undefined;
  }

  async createOrUpdateImmunoGraph(insertGraph: InsertImmunoGraph): Promise<ImmunoGraph> {
    const existing = await this.getImmunoGraph(insertGraph.userId || "default_user");
    
    if (existing) {
      const updateData: Partial<typeof immunoGraphs.$inferInsert> = {
        ...insertGraph,
        updatedAt: new Date(),
      };
      
      const [updated] = await db
        .update(immunoGraphs)
        .set(updateData)
        .where(eq(immunoGraphs.id, existing.id))
        .returning();
      return updated;
    } else {
      const [created] = await db
        .insert(immunoGraphs)
        .values(insertGraph as any)
        .returning();
      return created;
    }
  }
}

export const storage = new DatabaseStorage();
