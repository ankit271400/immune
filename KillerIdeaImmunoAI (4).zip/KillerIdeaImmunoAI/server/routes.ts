import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { analyzeHealthImage } from "./lib/openai";
import { generateImmunePredictions, generateTrajectory } from "./lib/predictions";
import type { ScanAnalysisRequest, ScanAnalysisResponse, HealthMetrics } from "@shared/schema";
import { z } from "zod";

const scanAnalysisRequestSchema = z.object({
  imageData: z.string(),
  duration: z.number(),
  frames: z.number(),
});

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/scans/analyze", async (req, res) => {
    try {
      const validationResult = scanAnalysisRequestSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        return res.status(400).json({ error: "Invalid request data", details: validationResult.error });
      }

      const { imageData, duration, frames } = validationResult.data as ScanAnalysisRequest;

      const analysis = await analyzeHealthImage(imageData);

      const metrics: HealthMetrics = {
        pulseRate: analysis.pulseRate,
        oxygenSaturation: analysis.oxygenSaturation,
        bloodPressureEstimate: analysis.bloodPressureEstimate,
        stressLevel: analysis.stressLevel,
        immuneResponseIndex: analysis.microVascularHealth,
      };

      // Get historical scans for prediction
      const historicalScans = await storage.getAllScans();
      
      // Generate ImmunoGraph™ predictions using historical data
      const tempScan = {
        ...analysis,
        id: "temp",
        timestamp: new Date(),
        metrics,
        riskLevel: analysis.riskLevel,
        analysisNotes: analysis.analysisNotes || "",
      } as any;
      
      const predictions = await generateImmunePredictions(tempScan, historicalScans);
      const trajectory = generateTrajectory(analysis.immunoScore, predictions, historicalScans);

      // Create the scan with predictions included
      const scan = await storage.createScan({
        immunoScore: analysis.immunoScore,
        heartRateVariability: analysis.heartRateVariability,
        capillaryRefillTime: analysis.capillaryRefillTime,
        perfusionIndex: analysis.perfusionIndex,
        thermalSignature: analysis.thermalSignature,
        microVascularHealth: analysis.microVascularHealth,
        riskLevel: analysis.riskLevel,
        imageData: imageData.substring(0, 100),
        analysisNotes: analysis.analysisNotes,
        metrics,
        predictions,
      });

      // Update ImmunoGraph for user
      await storage.createOrUpdateImmunoGraph({
        userId: "default_user",
        immuneReservePower: predictions.immuneReservePower,
        declineRate: predictions.declinePatterns.rate,
        recoveryProbability: predictions.recoveryProbability,
        predictedTrajectory: trajectory,
        confidenceScore: predictions.declinePatterns.confidence,
      });

      const response: ScanAnalysisResponse = {
        immunoScore: scan.immunoScore,
        riskLevel: scan.riskLevel as "low" | "moderate" | "high",
        metrics: scan.metrics!,
        heartRateVariability: scan.heartRateVariability!,
        capillaryRefillTime: scan.capillaryRefillTime!,
        perfusionIndex: scan.perfusionIndex!,
        thermalSignature: scan.thermalSignature!,
        microVascularHealth: scan.microVascularHealth!,
        analysisNotes: scan.analysisNotes || "",
        recommendations: analysis.recommendations,
        predictions,
      };

      res.json(response);
    } catch (error) {
      console.error("Scan analysis error:", error);
      res.status(500).json({ error: "Analysis failed. Please try again." });
    }
  });

  app.get("/api/scans", async (req, res) => {
    try {
      const scans = await storage.getAllScans();
      res.json(scans);
    } catch (error) {
      console.error("Get scans error:", error);
      res.status(500).json({ error: "Failed to retrieve scans" });
    }
  });

  app.get("/api/scans/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const scan = await storage.getScan(id);
      
      if (!scan) {
        return res.status(404).json({ error: "Scan not found" });
      }
      
      res.json(scan);
    } catch (error) {
      console.error("Get scan error:", error);
      res.status(500).json({ error: "Failed to retrieve scan" });
    }
  });

  app.get("/api/immunograph", async (req, res) => {
    try {
      const userId = (req.query.userId as string) || "default_user";
      const graph = await storage.getImmunoGraph(userId);
      
      if (!graph) {
        return res.status(404).json({ error: "ImmunoGraph not found. Complete at least one scan first." });
      }
      
      res.json(graph);
    } catch (error) {
      console.error("Get ImmunoGraph error:", error);
      res.status(500).json({ error: "Failed to retrieve ImmunoGraph" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
