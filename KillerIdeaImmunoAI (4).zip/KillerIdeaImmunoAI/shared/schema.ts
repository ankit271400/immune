import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, jsonb, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const scans = pgTable("scans", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  immunoScore: integer("immuno_score").notNull(),
  heartRateVariability: real("heart_rate_variability"),
  capillaryRefillTime: real("capillary_refill_time"),
  perfusionIndex: real("perfusion_index"),
  thermalSignature: real("thermal_signature"),
  microVascularHealth: real("micro_vascular_health"),
  riskLevel: text("risk_level").notNull(),
  imageData: text("image_data"),
  analysisNotes: text("analysis_notes"),
  metrics: jsonb("metrics").$type<HealthMetrics>(),
  predictions: jsonb("predictions").$type<ImmunePredictions>(),
});

export const immunoGraphs = pgTable("immuno_graphs", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: text("user_id").notNull().default("default_user"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
  immuneReservePower: real("immune_reserve_power"),
  declineRate: real("decline_rate"),
  recoveryProbability: real("recovery_probability"),
  predictedTrajectory: jsonb("predicted_trajectory").$type<TrajectoryPoint[]>(),
  confidenceScore: real("confidence_score"),
});

export const insertScanSchema = createInsertSchema(scans).omit({
  id: true,
  timestamp: true,
});

export type InsertScan = z.infer<typeof insertScanSchema>;
export type Scan = typeof scans.$inferSelect;

export interface HealthMetrics {
  pulseRate: number;
  oxygenSaturation: number;
  bloodPressureEstimate: {
    systolic: number;
    diastolic: number;
  };
  stressLevel: number;
  immuneResponseIndex: number;
}

export interface ScanAnalysisRequest {
  imageData: string;
  duration: number;
  frames: number;
}

export interface ScanAnalysisResponse {
  immunoScore: number;
  riskLevel: "low" | "moderate" | "high";
  metrics: HealthMetrics;
  heartRateVariability: number;
  capillaryRefillTime: number;
  perfusionIndex: number;
  thermalSignature: number;
  microVascularHealth: number;
  analysisNotes: string;
  recommendations: string[];
  predictions?: ImmunePredictions;
}

export interface ImmunePredictions {
  nextWeekScore: number;
  nextMonthScore: number;
  declinePatterns: {
    trend: "improving" | "stable" | "declining";
    rate: number;
    confidence: number;
  };
  recoveryProbability: number;
  immuneReservePower: number;
  riskFactors: string[];
  recommendations: string[];
}

export interface TrajectoryPoint {
  date: string;
  predictedScore: number;
  confidence: number;
  isActual: boolean;
}

export interface ImmunoGraphData {
  id: string;
  userId: string;
  immuneReservePower: number;
  declineRate: number;
  recoveryProbability: number;
  predictedTrajectory: TrajectoryPoint[];
  confidenceScore: number;
  createdAt: Date;
  updatedAt: Date;
}

export const insertImmunoGraphSchema = createInsertSchema(immunoGraphs).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertImmunoGraph = z.infer<typeof insertImmunoGraphSchema>;
export type ImmunoGraph = typeof immunoGraphs.$inferSelect;
